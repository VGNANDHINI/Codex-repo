import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer, { type FileFilterCallback } from "multer";
import path from "path";
import { insertClaimSchema, insertDocumentSchema, insertRecommendationSchema, insertSatelliteImagerySchema, insertCitizenReportSchema, insertAnomalyDetectionSchema, insertDroneDataSchema, insertWeatherDataSchema } from "@shared/schema";
import { documentProcessor } from "./ai-services/document-processor";
import { satelliteAnalyzer } from "./ai-services/satellite-analyzer";
import { predictiveAnalytics } from "./ai-services/predictive-analytics";
import { anomalyDetectionService } from "./ai-services/anomaly-detection";
import { blockchainService } from "./ai-services/blockchain-service";
import { languageService } from "./services/language-service";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  },
  fileFilter: (req: Express.Request, file: Express.Multer.File, cb: FileFilterCallback) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/json', // GeoJSON
      'application/zip', // Shapefiles
      'image/tiff',
      'image/geotiff'
    ];
    
    if (allowedTypes.includes(file.mimetype) || file.originalname.endsWith('.shp') || file.originalname.endsWith('.kml')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Villages endpoints
  app.get("/api/villages", async (req, res) => {
    try {
      const { state } = req.query;
      const villages = state 
        ? await storage.getVillagesByState(state as string)
        : await storage.getAllVillages();
      res.json(villages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch villages" });
    }
  });

  app.get("/api/villages/:id", async (req, res) => {
    try {
      const village = await storage.getVillageById(req.params.id);
      if (!village) {
        return res.status(404).json({ message: "Village not found" });
      }
      res.json(village);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch village" });
    }
  });

  // Claims endpoints
  app.get("/api/claims", async (req, res) => {
    try {
      const { villageId } = req.query;
      const claims = villageId 
        ? await storage.getClaimsByVillage(villageId as string)
        : await storage.getAllClaims();
      res.json(claims);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch claims" });
    }
  });

  app.post("/api/claims", async (req, res) => {
    try {
      const claimData = insertClaimSchema.parse(req.body);
      const claim = await storage.createClaim(claimData);
      res.status(201).json(claim);
    } catch (error) {
      res.status(400).json({ message: "Invalid claim data" });
    }
  });

  app.patch("/api/claims/:id/status", async (req, res) => {
    try {
      const { status, rejectionReason } = req.body;
      const approvalDate = status === 'approved' ? new Date() : undefined;
      const claim = await storage.updateClaimStatus(
        req.params.id, 
        status, 
        approvalDate, 
        rejectionReason
      );
      if (!claim) {
        return res.status(404).json({ message: "Claim not found" });
      }
      res.json(claim);
    } catch (error) {
      res.status(500).json({ message: "Failed to update claim status" });
    }
  });

  // Documents endpoints
  app.get("/api/documents", async (req, res) => {
    try {
      const { villageId, category } = req.query;
      let documents;
      if (villageId) {
        documents = await storage.getDocumentsByVillage(villageId as string);
      } else if (category) {
        documents = await storage.getDocumentsByCategory(category as string);
      } else {
        documents = await storage.getAllDocuments();
      }
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/documents/upload", upload.single('file'), async (req: MulterRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { category, villageId, claimId } = req.body;
      
      const documentData = {
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        category,
        villageId: villageId || null,
        claimId: claimId || null,
        filePath: req.file.path
      };

      const validatedData = insertDocumentSchema.parse(documentData);
      const document = await storage.createDocument(validatedData);
      
      res.status(201).json(document);
    } catch (error) {
      res.status(400).json({ message: "Failed to upload document" });
    }
  });

  // CSS Schemes endpoints
  app.get("/api/schemes", async (req, res) => {
    try {
      const schemes = await storage.getActiveSchemes();
      res.json(schemes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schemes" });
    }
  });

  app.get("/api/enrollments", async (req, res) => {
    try {
      const { villageId, schemeId } = req.query;
      let enrollments: any[] = [];
      if (villageId) {
        enrollments = await storage.getEnrollmentsByVillage(villageId as string);
      } else if (schemeId) {
        enrollments = await storage.getEnrollmentsByScheme(schemeId as string);
      }
      res.json(enrollments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  // DSS Recommendations endpoints
  app.get("/api/recommendations", async (req, res) => {
    try {
      const { villageId, priority } = req.query;
      let recommendations: any[] = [];
      if (villageId) {
        recommendations = await storage.getRecommendationsByVillage(villageId as string);
      } else if (priority) {
        recommendations = await storage.getRecommendationsByPriority(priority as string);
      }
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.post("/api/recommendations", async (req, res) => {
    try {
      const recommendationData = insertRecommendationSchema.parse(req.body);
      const recommendation = await storage.createRecommendation(recommendationData);
      res.status(201).json(recommendation);
    } catch (error) {
      res.status(400).json({ message: "Invalid recommendation data" });
    }
  });

  app.patch("/api/recommendations/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const recommendation = await storage.updateRecommendationStatus(req.params.id, status);
      if (!recommendation) {
        return res.status(404).json({ message: "Recommendation not found" });
      }
      res.json(recommendation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update recommendation status" });
    }
  });

  // Dashboard statistics endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const villages = await storage.getAllVillages();
      const claims = await storage.getAllClaims();
      
      const anomalies = await storage.getAllAnomalies();
      const citizenReports = await storage.getAllCitizenReports();
      const drones = await storage.getAllDroneData();
      const sensors = await storage.getAllSensorData();
      
      const stats = {
        totalVillages: villages.length,
        activeClaims: claims.filter(c => c.status === 'pending').length,
        pattasGranted: claims.filter(c => c.status === 'approved').length,
        areaMapping: 94, // Mock percentage
        criticalAnomalies: anomalies.filter(a => a.severity === 'critical').length,
        activeDrones: drones.filter(d => d.flightStatus === 'active').length,
        activeSensors: sensors.filter(s => s.status === 'active').length,
        totalReports: citizenReports.length,
        resolvedAnomalies: anomalies.filter(a => a.verificationStatus === 'resolved').length
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // AI Processing endpoints
  app.post("/api/ai/process-document/:documentId", async (req, res) => {
    try {
      const documentId = req.params.documentId;
      const document = await storage.getDocumentById(documentId);
      
      if (!document || !document.filePath) {
        return res.status(404).json({ message: "Document not found or missing file path" });
      }

      const result = await documentProcessor.processDocument(document.filePath, document.fileType);
      
      // Update document with AI processing results
      const updatedDocument = await storage.updateDocumentProcessed(documentId, true);
      
      res.json({
        document: updatedDocument,
        aiResults: result
      });
    } catch (error) {
      res.status(500).json({ message: "AI processing failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/ai/analyze-satellite/:villageId", async (req, res) => {
    try {
      const villageId = req.params.villageId;
      const village = await storage.getVillageById(villageId);
      
      if (!village) {
        return res.status(404).json({ message: "Village not found" });
      }

      const analysis = await satelliteAnalyzer.analyzeSatelliteImage(
        village.latitude,
        village.longitude,
        5 // 5km radius
      );
      
      // Store satellite analysis results
      const satelliteImageData = {
        villageId: village.id,
        imageUrl: analysis.imageUrl,
        imageType: "rgb",
        captureDate: analysis.metadata.captureDate,
        resolution: analysis.metadata.resolution,
        cloudCover: analysis.metadata.cloudCover,
        bounds: analysis.bounds,
        processedData: analysis.landUseClassification,
        processingStatus: "completed" as const
      };
      
      const savedImage = await storage.createSatelliteImage(satelliteImageData);
      
      res.json({
        village,
        analysis,
        savedImage
      });
    } catch (error) {
      res.status(500).json({ message: "Satellite analysis failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Enhanced DSS endpoint with AI recommendations
  app.post("/api/dss/generate-recommendations/:villageId", async (req, res) => {
    try {
      const villageId = req.params.villageId;
      const village = await storage.getVillageById(villageId);
      
      if (!village) {
        return res.status(404).json({ message: "Village not found" });
      }

      // Get latest satellite data and sensor readings
      const latestSatellite = await storage.getLatestSatelliteImage(villageId);
      const waterSensor = await storage.getLatestSensorReading(villageId, "water_quality");
      const soilSensor = await storage.getLatestSensorReading(villageId, "soil_moisture");
      
      // AI-generated recommendations based on available data
      const recommendations = [];
      
      // Water infrastructure recommendations
      if (village.waterIndex !== null && village.waterIndex < 50) {
        recommendations.push({
          villageId: village.id,
          title: "Water Infrastructure Priority",
          description: `${village.name} shows low water index (${village.waterIndex}%). Recommend borewell installation under Jal Jeevan Mission for ${village.population} residents.`,
          priority: "high",
          category: "water",
          estimatedCost: 500000,
          beneficiaries: village.population,
          aiGenerated: true,
          confidenceScore: 0.9,
          implementationTimeline: "3-6 months",
          expectedImpact: {
            waterIndexImprovement: 40,
            livelihoodImpact: 25
          }
        });
      }

      // Agriculture support recommendations
      if (village.pattasGranted > 0) {
        recommendations.push({
          villageId: village.id,
          title: "Agricultural Support Scheme",
          description: `${village.pattasGranted} patta holders in ${village.name} eligible for PM-KISAN benefits. Auto-enrollment recommended with digitized land records.`,
          priority: "medium",
          category: "agriculture",
          estimatedCost: village.pattasGranted * 6000,
          beneficiaries: village.pattasGranted,
          aiGenerated: true,
          confidenceScore: 0.85,
          implementationTimeline: "1-2 months",
          expectedImpact: {
            agricultureProductivityGain: 15,
            livelihoodImpact: 20
          }
        });
      }

      // Forest conservation recommendations
      if (village.forestHealthIndex !== null && village.forestHealthIndex < 60) {
        recommendations.push({
          villageId: village.id,
          title: "Forest Conservation Initiative",
          description: `Forest health index in ${village.name} is ${village.forestHealthIndex}%. Recommend community forest management under CFR with livelihood activities.`,
          priority: "high",
          category: "environment",
          estimatedCost: 750000,
          beneficiaries: Math.floor(village.population * 0.7),
          aiGenerated: true,
          confidenceScore: 0.88,
          implementationTimeline: "6-12 months",
          expectedImpact: {
            forestHealthImprovement: 30,
            livelihoodImpact: 35
          }
        });
      }

      // Save recommendations to storage
      const savedRecommendations = [];
      for (const rec of recommendations) {
        const saved = await storage.createRecommendation(rec);
        savedRecommendations.push(saved);
      }
      
      res.json({
        village,
        recommendations: savedRecommendations,
        dataUsed: {
          satelliteData: !!latestSatellite,
          waterSensorData: !!waterSensor,
          soilSensorData: !!soilSensor
        }
      });
    } catch (error) {
      res.status(500).json({ message: "DSS generation failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // IoT sensor data endpoints
  app.get("/api/sensors", async (req, res) => {
    try {
      const { villageId, sensorType } = req.query;
      let sensors;
      
      if (villageId) {
        sensors = await storage.getSensorDataByVillage(villageId as string);
      } else if (sensorType) {
        sensors = await storage.getSensorDataByType(sensorType as string);
      } else {
        sensors = await storage.getAllSensorData();
      }
      
      res.json(sensors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sensor data" });
    }
  });

  app.get("/api/satellite-images/:villageId", async (req, res) => {
    try {
      const villageId = req.params.villageId;
      const images = await storage.getSatelliteImagesByVillage(villageId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch satellite images" });
    }
  });

  // Enhanced AI-Powered FRA System Routes
  
  // Blockchain Patta Verification
  app.get("/api/blockchain-pattas", async (req, res) => {
    try {
      const pattas = await storage.getAllBlockchainPattas();
      res.json(pattas);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blockchain pattas" });
    }
  });

  app.get("/api/blockchain-pattas/claim/:claimId", async (req, res) => {
    try {
      const patta = await storage.getBlockchainPattaByClaimId(req.params.claimId);
      if (!patta) {
        return res.status(404).json({ message: "Blockchain patta not found" });
      }
      
      // Verify patta using blockchain service
      const verification = await blockchainService.verifyPatta(patta);
      
      res.json({ patta, verification });
    } catch (error) {
      res.status(500).json({ message: "Failed to verify blockchain patta" });
    }
  });

  app.post("/api/blockchain-pattas", async (req, res) => {
    try {
      const claim = await storage.getClaimById(req.body.claimId);
      if (!claim) {
        return res.status(404).json({ message: "Claim not found" });
      }
      
      const blockchainPatta = await blockchainService.createPattaRecord(claim);
      const savedPatta = await storage.createBlockchainPatta(blockchainPatta);
      
      res.status(201).json(savedPatta);
    } catch (error) {
      res.status(500).json({ message: "Failed to create blockchain patta" });
    }
  });

  // Drone Data and UAV Integration
  app.get("/api/drone-data", async (req, res) => {
    try {
      const { villageId } = req.query;
      const drones = villageId 
        ? await storage.getDroneDataByVillage(villageId as string)
        : await storage.getAllDroneData();
      res.json(drones);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch drone data" });
    }
  });

  app.get("/api/drone-data/active", async (req, res) => {
    try {
      const activeDrones = await storage.getActiveDrones();
      res.json(activeDrones);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active drones" });
    }
  });

  app.post("/api/drone-data", async (req, res) => {
    try {
      const droneData = await storage.createDroneData(req.body);
      
      // Process drone data for anomaly detection
      const anomalies = await anomalyDetectionService.detectDroneAnomalies([droneData], 
        await storage.getVillageById(droneData.villageId || ''));
      
      // Save detected anomalies
      for (const anomaly of anomalies) {
        await storage.createAnomaly({
          villageId: droneData.villageId,
          anomalyType: anomaly.type,
          severity: anomaly.severity,
          confidenceScore: anomaly.confidence,
          detectionMethod: anomaly.detectionMethod,
          location: anomaly.location,
          description: anomaly.description,
          evidenceUrls: anomaly.evidenceUrls
        });
      }
      
      res.status(201).json({ droneData, anomaliesDetected: anomalies.length });
    } catch (error) {
      res.status(500).json({ message: "Failed to create drone data" });
    }
  });

  // Multi-Language Translation
  app.get("/api/translations/:language", async (req, res) => {
    try {
      const translations = await storage.getTranslationsByLanguage(req.params.language);
      res.json(translations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch translations" });
    }
  });

  app.get("/api/translations/:language/:key", async (req, res) => {
    try {
      const translation = await storage.getTranslationByKey(req.params.key, req.params.language);
      if (!translation) {
        // Fallback to service default translation
        const defaultTranslation = languageService.translate(req.params.key, req.params.language);
        return res.json({ textKey: req.params.key, language: req.params.language, translation: defaultTranslation });
      }
      res.json(translation);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch translation" });
    }
  });

  app.get("/api/languages", async (req, res) => {
    try {
      const languages = languageService.getSupportedLanguages();
      res.json(languages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch supported languages" });
    }
  });

  // Weather Data Integration
  app.get("/api/weather-data", async (req, res) => {
    try {
      const { villageId, date } = req.query;
      if (villageId) {
        const weatherData = await storage.getWeatherDataByVillage(villageId as string);
        res.json(weatherData);
      } else {
        res.json([]);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  app.get("/api/weather-data/latest/:villageId", async (req, res) => {
    try {
      const latestWeather = await storage.getLatestWeatherData(req.params.villageId);
      res.json(latestWeather);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch latest weather data" });
    }
  });

  // Predictive Analytics
  app.post("/api/predictions/deforestation", async (req, res) => {
    try {
      const { villageId, timeframe } = req.body;
      const village = await storage.getVillageById(villageId);
      if (!village) {
        return res.status(404).json({ message: "Village not found" });
      }
      
      const weatherData = await storage.getWeatherDataByVillage(villageId);
      const satelliteData = await storage.getSatelliteImagesByVillage(villageId);
      
      const prediction = await predictiveAnalytics.predictDeforestation(village, weatherData, satelliteData, timeframe);
      
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate deforestation prediction" });
    }
  });

  app.post("/api/predictions/water-scarcity", async (req, res) => {
    try {
      const { villageId, timeframe } = req.body;
      const village = await storage.getVillageById(villageId);
      if (!village) {
        return res.status(404).json({ message: "Village not found" });
      }
      
      const weatherData = await storage.getWeatherDataByVillage(villageId);
      const iotData = await storage.getSensorDataByVillage(villageId);
      
      const prediction = await predictiveAnalytics.predictWaterScarcity(village, weatherData, iotData, timeframe);
      
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate water scarcity prediction" });
    }
  });

  app.post("/api/predictions/optimize-schemes", async (req, res) => {
    try {
      const { villageIds, budget } = req.body;
      const villages = await Promise.all(villageIds.map((id: string) => storage.getVillageById(id)));
      const validVillages = villages.filter(v => v !== undefined);
      const schemes = await storage.getActiveSchemes();
      
      const optimization = await predictiveAnalytics.optimizeSchemeAllocation(validVillages, schemes, budget);
      
      res.json(optimization);
    } catch (error) {
      res.status(500).json({ message: "Failed to optimize scheme allocation" });
    }
  });

  // Anomaly Detection
  app.get("/api/anomalies", async (req, res) => {
    try {
      const { villageId, severity } = req.query;
      let anomalies;
      
      if (villageId) {
        anomalies = await storage.getAnomaliesByVillage(villageId as string);
      } else if (severity) {
        anomalies = await storage.getAnomaliesBySeverity(severity as string);
      } else {
        anomalies = await storage.getAllAnomalies();
      }
      
      res.json(anomalies);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch anomalies" });
    }
  });

  app.post("/api/anomalies/detect", async (req, res) => {
    try {
      const { villageIds } = req.body;
      const villages = await Promise.all(villageIds.map((id: string) => storage.getVillageById(id)));
      const validVillages = villages.filter(v => v !== undefined);
      
      const satelliteData = await Promise.all(validVillages.map(v => storage.getSatelliteImagesByVillage(v.id)));
      const droneData = await Promise.all(validVillages.map(v => storage.getDroneDataByVillage(v.id)));
      const iotData = await Promise.all(validVillages.map(v => storage.getSensorDataByVillage(v.id)));
      
      const results = await anomalyDetectionService.processVillageBatch(
        validVillages,
        satelliteData.flat(),
        droneData.flat(),
        iotData.flat()
      );
      
      // Save detected anomalies
      const savedAnomalies = [];
      for (const result of results) {
        for (const anomaly of result.anomalies) {
          const saved = await storage.createAnomaly({
            villageId: result.villageId,
            anomalyType: anomaly.type,
            severity: anomaly.severity,
            confidenceScore: anomaly.confidence,
            detectionMethod: anomaly.detectionMethod,
            location: anomaly.location,
            description: anomaly.description,
            evidenceUrls: anomaly.evidenceUrls
          });
          savedAnomalies.push(saved);
        }
      }
      
      res.json({ detectedAnomalies: savedAnomalies.length, results });
    } catch (error) {
      res.status(500).json({ message: "Failed to detect anomalies" });
    }
  });

  // Citizen Engagement Platform
  app.get("/api/citizen-reports", async (req, res) => {
    try {
      const { citizenId } = req.query;
      const reports = citizenId 
        ? await storage.getCitizenReportsByUser(citizenId as string)
        : await storage.getAllCitizenReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch citizen reports" });
    }
  });

  app.get("/api/citizen-reports/community-feed", async (req, res) => {
    try {
      const publicReports = await storage.getPublicCitizenReports();
      res.json(publicReports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch community feed" });
    }
  });

  app.get("/api/citizen-reports/gamification", async (req, res) => {
    try {
      // Mock gamification stats - in production, this would be calculated based on user activity
      const mockStats = {
        totalPoints: 1250,
        level: 3,
        rank: 15,
        badges: [
          { name: "Environmental Guardian", description: "Reported 10+ environmental issues", earnedAt: "2024-01-15", icon: "🌱" },
          { name: "Community Helper", description: "Verified 5+ community reports", earnedAt: "2024-02-01", icon: "🤝" }
        ],
        achievements: [
          { title: "First Report", description: "Submit your first environmental report", progress: 1, target: 1, completed: true },
          { title: "Photo Evidence", description: "Include photos in 5 reports", progress: 3, target: 5, completed: false },
          { title: "Community Verifier", description: "Verify 10 community reports", progress: 2, target: 10, completed: false }
        ]
      };
      res.json(mockStats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch gamification stats" });
    }
  });

  app.post("/api/citizen-reports", async (req, res) => {
    try {
      const report = await storage.createCitizenReport(req.body);
      res.status(201).json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to create citizen report" });
    }
  });

  // IoT Sensors Real-time Data
  app.get("/api/iot-sensors/real-time", async (req, res) => {
    try {
      const activeSensors = await storage.getAllSensorData();
      const realTimeData = activeSensors.filter(sensor => 
        sensor.status === 'active' && 
        sensor.timestamp && 
        (new Date().getTime() - sensor.timestamp.getTime()) < 300000 // Last 5 minutes
      );
      res.json(realTimeData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch real-time sensor data" });
    }
  });

  // Scenario Simulations
  app.get("/api/simulations", async (req, res) => {
    try {
      const { userId } = req.query;
      const simulations = userId 
        ? await storage.getSimulationsByUser(userId as string)
        : await storage.getAllSimulations();
      res.json(simulations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch simulations" });
    }
  });

  app.post("/api/simulations", async (req, res) => {
    try {
      const simulation = await storage.createSimulation(req.body);
      res.status(201).json(simulation);
    } catch (error) {
      res.status(500).json({ message: "Failed to create simulation" });
    }
  });

  // Enhanced Satellite Imagery with AI Analysis
  app.get("/api/satellite-imagery", async (req, res) => {
    try {
      const { date, villageId } = req.query;
      let images = [];
      
      if (villageId) {
        images = await storage.getSatelliteImagesByVillage(villageId as string);
      }
      
      if (date) {
        const targetDate = new Date(date as string);
        images = images.filter(img => 
          img.captureDate.toDateString() === targetDate.toDateString()
        );
      }
      
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch satellite imagery" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
