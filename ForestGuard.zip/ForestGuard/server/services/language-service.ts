import { z } from "zod";

export interface LanguageConfig {
  code: string;
  name: string;
  nativeName: string;
  rtl: boolean;
  script: string;
  region: string[];
}

// All major Indian languages with regional coverage
export const SUPPORTED_LANGUAGES: Record<string, LanguageConfig> = {
  hi: {
    code: "hi",
    name: "Hindi",
    nativeName: "हिन्दी",
    rtl: false,
    script: "Devanagari",
    region: ["MP", "UP", "RJ", "HR", "JH", "CG", "UK", "DL", "HP", "BR"]
  },
  en: {
    code: "en",
    name: "English",
    nativeName: "English",
    rtl: false,
    script: "Latin",
    region: ["ALL"]
  },
  bn: {
    code: "bn",
    name: "Bengali",
    nativeName: "বাংলা",
    rtl: false,
    script: "Bengali",
    region: ["WB", "TR", "AS"]
  },
  ta: {
    code: "ta",
    name: "Tamil",
    nativeName: "தமிழ்",
    rtl: false,
    script: "Tamil",
    region: ["TN", "PY"]
  },
  te: {
    code: "te",
    name: "Telugu",
    nativeName: "తెలుగు",
    rtl: false,
    script: "Telugu",
    region: ["TS", "AP"]
  },
  mr: {
    code: "mr",
    name: "Marathi",
    nativeName: "मराठी",
    rtl: false,
    script: "Devanagari",
    region: ["MH", "GA"]
  },
  gu: {
    code: "gu",
    name: "Gujarati",
    nativeName: "ગુજરાતી",
    rtl: false,
    script: "Gujarati",
    region: ["GJ", "DD", "DN"]
  },
  kn: {
    code: "kn",
    name: "Kannada",
    nativeName: "ಕನ್ನಡ",
    rtl: false,
    script: "Kannada",
    region: ["KA"]
  },
  ml: {
    code: "ml",
    name: "Malayalam",
    nativeName: "മലയാളം",
    rtl: false,
    script: "Malayalam",
    region: ["KL", "LD"]
  },
  or: {
    code: "or",
    name: "Odia",
    nativeName: "ଓଡ଼ିଆ",
    rtl: false,
    script: "Odia",
    region: ["OD"]
  },
  pa: {
    code: "pa",
    name: "Punjabi",
    nativeName: "ਪੰਜਾਬੀ",
    rtl: false,
    script: "Gurmukhi",
    region: ["PB", "CH"]
  },
  as: {
    code: "as",
    name: "Assamese",
    nativeName: "অসমীয়া",
    rtl: false,
    script: "Bengali",
    region: ["AS"]
  },
  ur: {
    code: "ur",
    name: "Urdu",
    nativeName: "اردو",
    rtl: true,
    script: "Arabic",
    region: ["UP", "BR", "JK", "TS", "DL"]
  },
  sa: {
    code: "sa",
    name: "Sanskrit",
    nativeName: "संस्कृतम्",
    rtl: false,
    script: "Devanagari",
    region: ["UK", "HP"]
  },
  ne: {
    code: "ne",
    name: "Nepali",
    nativeName: "नेपाली",
    rtl: false,
    script: "Devanagari",
    region: ["SK", "WB"]
  },
  ks: {
    code: "ks",
    name: "Kashmiri",
    nativeName: "کٲشُر",
    rtl: true,
    script: "Arabic",
    region: ["JK"]
  },
  sd: {
    code: "sd",
    name: "Sindhi",
    nativeName: "سندھی",
    rtl: true,
    script: "Arabic",
    region: ["RJ", "GJ"]
  }
};

// Default translations for core FRA terminology
export const DEFAULT_TRANSLATIONS: Record<string, Record<string, string>> = {
  // Core FRA Terms
  "fra_title": {
    en: "Forest Rights Act",
    hi: "वन अधिकार अधिनियम",
    bn: "বন অধিকার আইন",
    ta: "வன உரிமைச் சட்டம்",
    te: "అటవీ హక్కుల చట్టం",
    mr: "वन हक्क कायदा",
    gu: "વન અધિકાર અધિનિયમ",
    kn: "ಅರಣ್ಯ ಹಕ್ಕುಗಳ ಕಾಯಿದೆ",
    ml: "വന അവകാശ നിയമം",
    or: "ବନ ଅଧିକାର ଆଇନ",
    pa: "ਜੰਗਲ ਅਧਿਕਾਰ ਐਕਟ",
    as: "বন অধিকাৰ আইন",
    ur: "جنگلات کے حقوق کا قانون"
  },
  "ifr": {
    en: "Individual Forest Rights",
    hi: "व्यक्तिगत वन अधिकार",
    bn: "ব্যক্তিগত বন অধিকার",
    ta: "தனிப்பட்ட வன உரिமைகள்",
    te: "వ్యక్తిగత అటవీ హక్కులు",
    mr: "वैयक्तिक वन हक्क",
    gu: "વ્યક્તિગત વન અધિકાર",
    kn: "ವೈಯಕ್ತಿಕ ಅರಣ್ಯ ಹಕ್ಕುಗಳು",
    ml: "വ്യക്തിഗത വന അവകാശങ്ങൾ",
    or: "ବ୍ୟକ୍ତିଗତ ବନ ଅଧିକାର",
    pa: "ਵਿਅਕਤੀਗਤ ਜੰਗਲ ਅਧਿਕਾਰ",
    as: "ব্যক্তিগত বন অধিকাৰ",
    ur: "انفرادی جنگلاتی حقوق"
  },
  "cfr": {
    en: "Community Forest Resource Rights",
    hi: "सामुदायिक वन संसाधन अधिकार",
    bn: "সমुদায়িক বন সম্পদ অধিকার",
    ta: "சமூக வன வள உரிமைகள்",
    te: "కమ్యూనిటీ అటవీ వనరుల హక్కులు",
    mr: "सामुदायिक वन संसाधन हक्क",
    gu: "સામુદાયિક વન સંસાધન અધિકાર",
    kn: "ಸಮುದಾಯ ಅರಣ್ಯ ಸಂಪನ್ಮೂಲ ಹಕ್ಕುಗಳು",
    ml: "കമ്മ്യൂണിറ്റി വന വിഭവ അവകാശങ്ങൾ",
    or: "ସମ୍ପ୍ରଦାୟ ବନ ସମ୍ପଦ ଅଧିକାର",
    pa: "ਭਾਈਚਾਰਕ ਜੰਗਲ ਸਰੋਤ ਅਧਿਕਾਰ",
    as: "সম্প্ৰদায়িক বন সম্পদ অধিকাৰ",
    ur: "کمیونٹی جنگلاتی وسائل کے حقوق"
  },
  "patta": {
    en: "Land Title Document",
    hi: "पट्टा दस्तावेज़",
    bn: "ভূমি স্বত্ব দলিল",
    ta: "நில உரிமை ஆவணம்",
    te: "భూమి హక్కు పత్రం",
    mr: "जमीन हक्काचा दस्तावेज",
    gu: "જમીન હક્કનો દસ્તાવેજ",
    kn: "ಭೂಮಿ ಹಕ್ಕು ದಾಖಲೆ",
    ml: "ഭൂമി അവകാശ രേഖ",
    or: "ଜମି ଅଧିକାର ଦଲିଲ",
    pa: "ਜ਼ਮੀਨ ਹੱਕ ਦਸਤਾਵੇਜ਼",
    as: "ভূমি অধিকাৰ দলিল",
    ur: "زمین کے حقوق کی دستاویز"
  },
  "village": {
    en: "Village",
    hi: "गाँव",
    bn: "গ্রাম",
    ta: "கிராமம்",
    te: "గ్రామం",
    mr: "गाव",
    gu: "ગામ",
    kn: "ಗ್ರಾಮ",
    ml: "ഗ്രാമം",
    or: "ଗାଁ",
    pa: "ਪਿੰਡ",
    as: "গাঁও",
    ur: "گاؤں"
  },
  "forest": {
    en: "Forest",
    hi: "वन",
    bn: "বন",
    ta: "காடு",
    te: "అడవి",
    mr: "जंगल",
    gu: "જંગલ",
    kn: "ಅರಣ್ಯ",
    ml: "കാട്",
    or: "ବନ",
    pa: "ਜੰਗਲ",
    as: "অৰণ্য",
    ur: "جنگل"
  },
  "water": {
    en: "Water",
    hi: "पानी",
    bn: "পানি",
    ta: "நீர்",
    te: "నీరు",
    mr: "पाणी",
    gu: "પાણી",
    kn: "ನೀರು",
    ml: "വെള്ളം",
    or: "ପାଣି",
    pa: "ਪਾਣੀ",
    as: "পানী",
    ur: "پانی"
  },
  "agriculture": {
    en: "Agriculture",
    hi: "कृषि",
    bn: "কৃষি",
    ta: "விவசாயம்",
    te: "వ్యవసాయం",
    mr: "शेती",
    gu: "ખેતી",
    kn: "ಕೃಷಿ",
    ml: "കൃഷി",
    or: "କୃଷି",
    pa: "ਖੇਤੀ",
    as: "কৃষি",
    ur: "زراعت"
  },
  "status_pending": {
    en: "Pending",
    hi: "लंबित",
    bn: "অপেক্ষমাণ",
    ta: "நிலுவையில்",
    te: "పెండింగ్",
    mr: "प्रलंबित",
    gu: "પેન્ડિંગ",
    kn: "ಬಾಕಿ",
    ml: "തീർപ്പുകൽപ്പിക്കാത്ത",
    or: "ବାକି",
    pa: "ਬਾਕੀ",
    as: "বাকী",
    ur: "زیر التواء"
  },
  "status_approved": {
    en: "Approved",
    hi: "अनुमोदित",
    bn: "অনুমোদিত",
    ta: "அங்கீகரிக்கப்பட்டது",
    te: "ఆమోదించబడింది",
    mr: "मंजूर",
    gu: "મંજૂર",
    kn: "ಅನುಮೋದಿತ",
    ml: "അനുമോദിച്ചു",
    or: "ଅନୁମୋଦିତ",
    pa: "ਮਨਜ਼ੂਰ",
    as: "অনুমোদিত",
    ur: "منظور شدہ"
  },
  "dashboard": {
    en: "Dashboard",
    hi: "डैशबोर्ड",
    bn: "ড্যাশবোর্ড",
    ta: "தகவல் பலகை",
    te: "డాష్‌బోర్డ్",
    mr: "डॅशबोर्ड",
    gu: "ડેશબોર્ડ",
    kn: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    ml: "ഡാഷ്ബോർഡ്",
    or: "ଡ୍ୟାସବୋର୍ଡ",
    pa: "ਡੈਸ਼ਬੋਰਡ",
    as: "ডেশ্বব'ৰ্ড",
    ur: "ڈیش بورڈ"
  }
};

export class LanguageService {
  private translations: Map<string, Map<string, string>> = new Map();
  private defaultLanguage = "en";
  private fallbackLanguage = "hi";

  constructor() {
    this.loadDefaultTranslations();
  }

  private loadDefaultTranslations() {
    Object.entries(DEFAULT_TRANSLATIONS).forEach(([key, translations]) => {
      const translationMap = new Map<string, string>();
      Object.entries(translations).forEach(([lang, text]) => {
        translationMap.set(lang, text);
      });
      this.translations.set(key, translationMap);
    });
  }

  translate(key: string, language: string = this.defaultLanguage): string {
    const translationMap = this.translations.get(key);
    if (!translationMap) {
      console.warn(`Translation key "${key}" not found`);
      return key;
    }

    // Try requested language
    let translation = translationMap.get(language);
    if (translation) return translation;

    // Try fallback language
    translation = translationMap.get(this.fallbackLanguage);
    if (translation) return translation;

    // Try default language
    translation = translationMap.get(this.defaultLanguage);
    if (translation) return translation;

    // Return key as last resort
    return key;
  }

  addTranslation(key: string, language: string, text: string) {
    if (!this.translations.has(key)) {
      this.translations.set(key, new Map());
    }
    this.translations.get(key)!.set(language, text);
  }

  getSupportedLanguages(): LanguageConfig[] {
    return Object.values(SUPPORTED_LANGUAGES);
  }

  getLanguageByRegion(stateCode: string): string[] {
    const languages: string[] = [];
    Object.entries(SUPPORTED_LANGUAGES).forEach(([code, config]) => {
      if (config.region.includes("ALL") || config.region.includes(stateCode)) {
        languages.push(code);
      }
    });
    return languages;
  }

  isRTL(language: string): boolean {
    return SUPPORTED_LANGUAGES[language]?.rtl || false;
  }

  getLanguageScript(language: string): string {
    return SUPPORTED_LANGUAGES[language]?.script || "Latin";
  }

  // Dynamic translation for AI-generated content
  async translateWithAI(text: string, fromLang: string, toLang: string): Promise<string> {
    // This would integrate with translation APIs like Google Translate, Azure, or local models
    // For now, return the original text
    return text;
  }

  // Bulk translation for documents
  async translateDocument(content: string, targetLanguages: string[]): Promise<Record<string, string>> {
    const translations: Record<string, string> = {};
    
    for (const lang of targetLanguages) {
      // This would use AI translation services
      translations[lang] = content; // Placeholder
    }
    
    return translations;
  }

  // Regional number formatting
  formatNumber(number: number, language: string): string {
    try {
      const locale = this.getLocaleFromLanguage(language);
      return new Intl.NumberFormat(locale).format(number);
    } catch {
      return number.toString();
    }
  }

  // Regional date formatting
  formatDate(date: Date, language: string): string {
    try {
      const locale = this.getLocaleFromLanguage(language);
      return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }).format(date);
    } catch {
      return date.toLocaleDateString();
    }
  }

  private getLocaleFromLanguage(language: string): string {
    const localeMap: Record<string, string> = {
      hi: "hi-IN",
      bn: "bn-IN",
      ta: "ta-IN",
      te: "te-IN",
      mr: "mr-IN",
      gu: "gu-IN",
      kn: "kn-IN",
      ml: "ml-IN",
      or: "or-IN",
      pa: "pa-IN",
      as: "as-IN",
      ur: "ur-IN",
      en: "en-IN"
    };
    return localeMap[language] || "en-IN";
  }

  // Get language-specific input methods
  getInputMethod(language: string): string {
    const inputMethods: Record<string, string> = {
      hi: "devanagari",
      bn: "bengali",
      ta: "tamil",
      te: "telugu",
      mr: "devanagari",
      gu: "gujarati",
      kn: "kannada",
      ml: "malayalam",
      or: "odia",
      pa: "gurmukhi",
      as: "bengali",
      ur: "urdu"
    };
    return inputMethods[language] || "latin";
  }
}

export const languageService = new LanguageService();