import { 
  type Village, type InsertVillage,
  type Claim, type InsertClaim,
  type Document, type InsertDocument,
  type Scheme, type InsertScheme,
  type Enrollment, type InsertEnrollment,
  type Recommendation, type InsertRecommendation,
  type IotSensor, type InsertIotSensor,
  type SatelliteImage, type InsertSatelliteImage,
  type User, type InsertUser,
  type FieldData, type InsertFieldData,
  type BlockchainPatta, type InsertBlockchainPatta,
  type DroneData, type InsertDroneData,
  type LanguageTranslation, type InsertLanguageTranslation,
  type WeatherData, type InsertWeatherData,
  type PredictiveModel, type InsertPredictiveModel,
  type AnomalyDetection, type InsertAnomalyDetection,
  type CitizenReport, type InsertCitizenReport,
  type ScenarioSimulation, type InsertScenarioSimulation
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Villages
  getAllVillages(): Promise<Village[]>;
  getVillagesByState(state: string): Promise<Village[]>;
  getVillageById(id: string): Promise<Village | undefined>;
  createVillage(village: InsertVillage): Promise<Village>;
  
  // Claims
  getAllClaims(): Promise<Claim[]>;
  getClaimsByVillage(villageId: string): Promise<Claim[]>;
  getClaimById(id: string): Promise<Claim | undefined>;
  createClaim(claim: InsertClaim): Promise<Claim>;
  updateClaimStatus(id: string, status: string, approvalDate?: Date, rejectionReason?: string): Promise<Claim | undefined>;
  
  // Documents
  getAllDocuments(): Promise<Document[]>;
  getDocumentsByVillage(villageId: string): Promise<Document[]>;
  getDocumentsByCategory(category: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocumentProcessed(id: string, processed: boolean): Promise<Document | undefined>;
  
  // CSS Schemes
  getAllSchemes(): Promise<Scheme[]>;
  getActiveSchemes(): Promise<Scheme[]>;
  createScheme(scheme: InsertScheme): Promise<Scheme>;
  
  // Enrollments
  getEnrollmentsByVillage(villageId: string): Promise<Enrollment[]>;
  getEnrollmentsByScheme(schemeId: string): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollment(id: string, enrolled: number, coverage: number): Promise<Enrollment | undefined>;
  
  // DSS Recommendations
  getRecommendationsByVillage(villageId: string): Promise<Recommendation[]>;
  getRecommendationsByPriority(priority: string): Promise<Recommendation[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  updateRecommendationStatus(id: string, status: string): Promise<Recommendation | undefined>;
  
  // IoT Sensors
  getAllSensorData(): Promise<IotSensor[]>;
  getSensorDataByVillage(villageId: string): Promise<IotSensor[]>;
  getSensorDataByType(sensorType: string): Promise<IotSensor[]>;
  createSensorData(sensorData: InsertIotSensor): Promise<IotSensor>;
  getLatestSensorReading(villageId: string, sensorType: string): Promise<IotSensor | undefined>;
  
  // Satellite Imagery
  getSatelliteImagesByVillage(villageId: string): Promise<SatelliteImage[]>;
  createSatelliteImage(imageData: InsertSatelliteImage): Promise<SatelliteImage>;
  getLatestSatelliteImage(villageId: string): Promise<SatelliteImage | undefined>;
  
  // Users
  getAllUsers(): Promise<User[]>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(userData: InsertUser): Promise<User>;
  updateUserLastLogin(id: string): Promise<User | undefined>;
  
  // Field Data Collection
  getFieldDataByVillage(villageId: string): Promise<FieldData[]>;
  getFieldDataByUser(userId: string): Promise<FieldData[]>;
  createFieldData(fieldData: InsertFieldData): Promise<FieldData>;
  
  // Blockchain Pattas
  getAllBlockchainPattas(): Promise<BlockchainPatta[]>;
  getBlockchainPattaByClaimId(claimId: string): Promise<BlockchainPatta | undefined>;
  createBlockchainPatta(patta: InsertBlockchainPatta): Promise<BlockchainPatta>;
  updateBlockchainPattaVerification(id: string, status: string): Promise<BlockchainPatta | undefined>;
  
  // Drone Data
  getAllDroneData(): Promise<DroneData[]>;
  getDroneDataByVillage(villageId: string): Promise<DroneData[]>;
  createDroneData(droneData: InsertDroneData): Promise<DroneData>;
  getActiveDrones(): Promise<DroneData[]>;
  
  // Language Translations
  getTranslationsByLanguage(language: string): Promise<LanguageTranslation[]>;
  getTranslationByKey(textKey: string, language: string): Promise<LanguageTranslation | undefined>;
  createTranslation(translation: InsertLanguageTranslation): Promise<LanguageTranslation>;
  
  // Weather Data
  getWeatherDataByVillage(villageId: string): Promise<WeatherData[]>;
  getLatestWeatherData(villageId: string): Promise<WeatherData | undefined>;
  createWeatherData(weatherData: InsertWeatherData): Promise<WeatherData>;
  
  // Predictive Models
  getAllPredictiveModels(): Promise<PredictiveModel[]>;
  getActiveModel(modelType: string): Promise<PredictiveModel | undefined>;
  createPredictiveModel(model: InsertPredictiveModel): Promise<PredictiveModel>;
  
  // Anomaly Detection
  getAllAnomalies(): Promise<AnomalyDetection[]>;
  getAnomaliesByVillage(villageId: string): Promise<AnomalyDetection[]>;
  getAnomaliesBySeverity(severity: string): Promise<AnomalyDetection[]>;
  createAnomaly(anomaly: InsertAnomalyDetection): Promise<AnomalyDetection>;
  
  // Citizen Reports
  getAllCitizenReports(): Promise<CitizenReport[]>;
  getCitizenReportsByUser(citizenId: string): Promise<CitizenReport[]>;
  getPublicCitizenReports(): Promise<CitizenReport[]>;
  createCitizenReport(report: InsertCitizenReport): Promise<CitizenReport>;
  updateCitizenReportStatus(id: string, status: string): Promise<CitizenReport | undefined>;
  
  // Scenario Simulations
  getAllSimulations(): Promise<ScenarioSimulation[]>;
  getSimulationsByUser(userId: string): Promise<ScenarioSimulation[]>;
  createSimulation(simulation: InsertScenarioSimulation): Promise<ScenarioSimulation>;
  updateFieldDataVerification(id: string, status: string): Promise<FieldData | undefined>;
}

export class MemStorage implements IStorage {
  private villages: Map<string, Village> = new Map();
  private claims: Map<string, Claim> = new Map();
  private documents: Map<string, Document> = new Map();
  private schemes: Map<string, Scheme> = new Map();
  private enrollments: Map<string, Enrollment> = new Map();
  private recommendations: Map<string, Recommendation> = new Map();
  private sensors: Map<string, IotSensor> = new Map();
  private satelliteImages: Map<string, SatelliteImage> = new Map();
  private users: Map<string, User> = new Map();
  private fieldData: Map<string, FieldData> = new Map();
  private blockchainPattas: Map<string, BlockchainPatta> = new Map();
  private droneData: Map<string, DroneData> = new Map();
  private languageTranslations: Map<string, LanguageTranslation> = new Map();
  private weatherData: Map<string, WeatherData> = new Map();
  private predictiveModels: Map<string, PredictiveModel> = new Map();
  private anomalies: Map<string, AnomalyDetection> = new Map();
  private citizenReports: Map<string, CitizenReport> = new Map();
  private scenarioSimulations: Map<string, ScenarioSimulation> = new Map();

  constructor() {
    this.initializeMockData();
  }

  private initializeMockData() {
    // Initialize villages for target states
    const mockVillages: InsertVillage[] = [
      {
        name: "Chiraidongri", state: "Madhya Pradesh", district: "Betul",
        latitude: 21.9162, longitude: 77.8081, totalClaims: 47, pattasGranted: 31,
        forestArea: 1247, population: 2340,
        assets: { agriculturalLand: 423, waterBodies: 12, forestCover: 78, homesteads: 156 }
      },
      {
        name: "Kanchanpur", state: "Tripura", district: "North Tripura",
        latitude: 24.3267, longitude: 91.9681, totalClaims: 32, pattasGranted: 28,
        forestArea: 890, population: 1890,
        assets: { agriculturalLand: 234, waterBodies: 8, forestCover: 65, homesteads: 98 }
      },
      {
        name: "Rayagada", state: "Odisha", district: "Rayagada",
        latitude: 19.1648, longitude: 83.4158, totalClaims: 56, pattasGranted: 42,
        forestArea: 1567, population: 3200,
        assets: { agriculturalLand: 567, waterBodies: 15, forestCover: 82, homesteads: 201 }
      },
      {
        name: "Warangal Rural", state: "Telangana", district: "Warangal",
        latitude: 17.9689, longitude: 79.5941, totalClaims: 23, pattasGranted: 19,
        forestArea: 678, population: 1560,
        assets: { agriculturalLand: 345, waterBodies: 6, forestCover: 58, homesteads: 89 }
      }
    ];

    mockVillages.forEach(village => {
      this.createVillage(village);
    });

    // Initialize CSS schemes
    const mockSchemes: InsertScheme[] = [
      { name: "PM-KISAN", description: "Direct Income Support to Farmers", benefitAmount: 6000, isActive: true },
      { name: "Jal Jeevan Mission", description: "Tap Water Connection to Rural Households", benefitAmount: 0, isActive: true },
      { name: "MGNREGA", description: "Employment Guarantee Scheme", benefitAmount: 0, isActive: true },
      { name: "DAJGUA", description: "Integrated Development of Tribal Areas", benefitAmount: 0, isActive: true }
    ];

    mockSchemes.forEach(scheme => {
      this.createScheme(scheme);
    });
  }

  // Villages
  async getAllVillages(): Promise<Village[]> {
    return Array.from(this.villages.values());
  }

  async getVillagesByState(state: string): Promise<Village[]> {
    return Array.from(this.villages.values()).filter(v => v.state === state);
  }

  async getVillageById(id: string): Promise<Village | undefined> {
    return this.villages.get(id);
  }

  async createVillage(insertVillage: InsertVillage): Promise<Village> {
    const id = randomUUID();
    const village: Village = { 
      ...insertVillage,
      id, 
      createdAt: new Date(),
      totalClaims: insertVillage.totalClaims ?? 0,
      pattasGranted: insertVillage.pattasGranted ?? 0,
      forestArea: insertVillage.forestArea ?? 0,
      population: insertVillage.population ?? 0,
      waterIndex: insertVillage.waterIndex ?? 0,
      forestHealthIndex: insertVillage.forestHealthIndex ?? 0,
      soilQualityIndex: insertVillage.soilQualityIndex ?? 0,
      lastAiAnalysis: insertVillage.lastAiAnalysis ?? null,
      satelliteImageUrl: insertVillage.satelliteImageUrl ?? null,
      assets: insertVillage.assets ?? null,
    };
    this.villages.set(id, village);
    return village;
  }

  // Claims
  async getAllClaims(): Promise<Claim[]> {
    return Array.from(this.claims.values());
  }

  async getClaimsByVillage(villageId: string): Promise<Claim[]> {
    return Array.from(this.claims.values()).filter(c => c.villageId === villageId);
  }

  async getClaimById(id: string): Promise<Claim | undefined> {
    return this.claims.get(id);
  }

  async createClaim(insertClaim: InsertClaim): Promise<Claim> {
    const id = randomUUID();
    const claim: Claim = { 
      ...insertClaim, 
      id, 
      submissionDate: new Date(),
      approvalDate: null,
      rejectionReason: null,
      area: insertClaim.area ?? 0,
      villageId: insertClaim.villageId ?? null,
      aiExtractedData: insertClaim.aiExtractedData ?? null,
      processingStatus: insertClaim.processingStatus ?? "pending",
    };
    this.claims.set(id, claim);
    return claim;
  }

  async updateClaimStatus(id: string, status: string, approvalDate?: Date, rejectionReason?: string): Promise<Claim | undefined> {
    const claim = this.claims.get(id);
    if (!claim) return undefined;
    
    const updatedClaim = {
      ...claim,
      status,
      approvalDate: approvalDate || null,
      rejectionReason: rejectionReason || null
    };
    this.claims.set(id, updatedClaim);
    return updatedClaim;
  }

  // Documents
  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async getDocumentsByVillage(villageId: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(d => d.villageId === villageId);
  }

  async getDocumentsByCategory(category: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(d => d.category === category);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const document: Document = { 
      ...insertDocument, 
      id, 
      uploadedAt: new Date(),
      processed: insertDocument.processed ?? false,
      fileSize: insertDocument.fileSize ?? 0,
      villageId: insertDocument.villageId ?? null,
      claimId: insertDocument.claimId ?? null,
      filePath: insertDocument.filePath ?? null,
      ocrText: insertDocument.ocrText ?? null,
      nerEntities: insertDocument.nerEntities ?? null,
      aiConfidence: insertDocument.aiConfidence ?? 0,
      processingErrors: insertDocument.processingErrors ?? null,
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocumentProcessed(id: string, processed: boolean): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    
    const updatedDocument = { ...document, processed };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  // CSS Schemes
  async getAllSchemes(): Promise<Scheme[]> {
    return Array.from(this.schemes.values());
  }

  async getActiveSchemes(): Promise<Scheme[]> {
    return Array.from(this.schemes.values()).filter(s => s.isActive);
  }

  async createScheme(insertScheme: InsertScheme): Promise<Scheme> {
    const id = randomUUID();
    const scheme: Scheme = { 
      ...insertScheme, 
      id,
      description: insertScheme.description ?? null,
      eligibilityCriteria: insertScheme.eligibilityCriteria ?? null,
      benefitAmount: insertScheme.benefitAmount ?? null,
      isActive: insertScheme.isActive ?? true,
    };
    this.schemes.set(id, scheme);
    return scheme;
  }

  // Enrollments
  async getEnrollmentsByVillage(villageId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(e => e.villageId === villageId);
  }

  async getEnrollmentsByScheme(schemeId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(e => e.schemeId === schemeId);
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const id = randomUUID();
    const enrollment: Enrollment = { 
      ...insertEnrollment, 
      id, 
      lastUpdated: new Date(),
      villageId: insertEnrollment.villageId ?? null,
      schemeId: insertEnrollment.schemeId ?? null,
      eligible: insertEnrollment.eligible ?? 0,
      enrolled: insertEnrollment.enrolled ?? 0,
      coverage: insertEnrollment.coverage ?? 0,
      aiRecommendedPriority: insertEnrollment.aiRecommendedPriority ?? "medium",
      predictedImpact: insertEnrollment.predictedImpact ?? 0,
    };
    this.enrollments.set(id, enrollment);
    return enrollment;
  }

  async updateEnrollment(id: string, enrolled: number, coverage: number): Promise<Enrollment | undefined> {
    const enrollment = this.enrollments.get(id);
    if (!enrollment) return undefined;
    
    const updatedEnrollment = {
      ...enrollment,
      enrolled,
      coverage,
      lastUpdated: new Date()
    };
    this.enrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }

  // DSS Recommendations
  async getRecommendationsByVillage(villageId: string): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values()).filter(r => r.villageId === villageId);
  }

  async getRecommendationsByPriority(priority: string): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values()).filter(r => r.priority === priority);
  }

  async createRecommendation(insertRecommendation: InsertRecommendation): Promise<Recommendation> {
    const id = randomUUID();
    const recommendation: Recommendation = { 
      ...insertRecommendation, 
      id, 
      createdAt: new Date(),
      villageId: insertRecommendation.villageId ?? null,
      status: insertRecommendation.status ?? "pending",
      estimatedCost: insertRecommendation.estimatedCost ?? null,
      beneficiaries: insertRecommendation.beneficiaries ?? null,
      aiGenerated: insertRecommendation.aiGenerated ?? true,
      confidenceScore: insertRecommendation.confidenceScore ?? 0,
      implementationTimeline: insertRecommendation.implementationTimeline ?? null,
      expectedImpact: insertRecommendation.expectedImpact ?? null,
    };
    this.recommendations.set(id, recommendation);
    return recommendation;
  }

  async updateRecommendationStatus(id: string, status: string): Promise<Recommendation | undefined> {
    const recommendation = this.recommendations.get(id);
    if (!recommendation) return undefined;
    
    const updatedRecommendation = { ...recommendation, status };
    this.recommendations.set(id, updatedRecommendation);
    return updatedRecommendation;
  }

  // IoT Sensors implementation
  async getAllSensorData(): Promise<IotSensor[]> {
    return Array.from(this.sensors.values());
  }

  async getSensorDataByVillage(villageId: string): Promise<IotSensor[]> {
    return Array.from(this.sensors.values()).filter(s => s.villageId === villageId);
  }

  async getSensorDataByType(sensorType: string): Promise<IotSensor[]> {
    return Array.from(this.sensors.values()).filter(s => s.sensorType === sensorType);
  }

  async createSensorData(insertSensorData: InsertIotSensor): Promise<IotSensor> {
    const id = randomUUID();
    const sensorData: IotSensor = {
      ...insertSensorData,
      id,
      timestamp: new Date(),
      villageId: insertSensorData.villageId ?? null,
      batteryLevel: insertSensorData.batteryLevel ?? null,
      status: insertSensorData.status ?? "active",
      readings: insertSensorData.readings ?? null,
    };
    this.sensors.set(id, sensorData);
    return sensorData;
  }

  async getLatestSensorReading(villageId: string, sensorType: string): Promise<IotSensor | undefined> {
    const readings = Array.from(this.sensors.values())
      .filter(s => s.villageId === villageId && s.sensorType === sensorType)
      .sort((a, b) => (b.timestamp?.getTime() ?? 0) - (a.timestamp?.getTime() ?? 0));
    return readings[0];
  }

  // Satellite Imagery implementation
  async getSatelliteImagesByVillage(villageId: string): Promise<SatelliteImage[]> {
    return Array.from(this.satelliteImages.values()).filter(img => img.villageId === villageId);
  }

  async createSatelliteImage(insertImageData: InsertSatelliteImage): Promise<SatelliteImage> {
    const id = randomUUID();
    const imageData: SatelliteImage = {
      ...insertImageData,
      id,
      villageId: insertImageData.villageId ?? null,
      resolution: insertImageData.resolution ?? null,
      cloudCover: insertImageData.cloudCover ?? null,
      bounds: insertImageData.bounds ?? null,
      processedData: insertImageData.processedData ?? null,
      processingStatus: insertImageData.processingStatus ?? "pending",
    };
    this.satelliteImages.set(id, imageData);
    return imageData;
  }

  async getLatestSatelliteImage(villageId: string): Promise<SatelliteImage | undefined> {
    const images = Array.from(this.satelliteImages.values())
      .filter(img => img.villageId === villageId)
      .sort((a, b) => b.captureDate.getTime() - a.captureDate.getTime());
    return images[0];
  }

  // Users implementation
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUserById(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUserData: InsertUser): Promise<User> {
    const id = randomUUID();
    const userData: User = {
      ...insertUserData,
      id,
      createdAt: new Date(),
      lastLogin: null,
      department: insertUserData.department ?? null,
      state: insertUserData.state ?? null,
      district: insertUserData.district ?? null,
      permissions: insertUserData.permissions ?? null,
      isActive: insertUserData.isActive ?? true,
    };
    this.users.set(id, userData);
    return userData;
  }

  async updateUserLastLogin(id: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, lastLogin: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Field Data Collection implementation
  async getFieldDataByVillage(villageId: string): Promise<FieldData[]> {
    return Array.from(this.fieldData.values()).filter(data => data.villageId === villageId);
  }

  async getFieldDataByUser(userId: string): Promise<FieldData[]> {
    return Array.from(this.fieldData.values()).filter(data => data.userId === userId);
  }

  async createFieldData(insertFieldData: InsertFieldData): Promise<FieldData> {
    const id = randomUUID();
    const fieldDataEntry: FieldData = {
      ...insertFieldData,
      id,
      collectionDate: new Date(),
      userId: insertFieldData.userId ?? null,
      villageId: insertFieldData.villageId ?? null,
      collectedData: insertFieldData.collectedData ?? null,
      geoLocation: insertFieldData.geoLocation ?? null,
      images: insertFieldData.images ?? null,
      notes: insertFieldData.notes ?? null,
      verificationStatus: insertFieldData.verificationStatus ?? "pending",
    };
    this.fieldData.set(id, fieldDataEntry);
    return fieldDataEntry;
  }

  async updateFieldDataVerification(id: string, status: string): Promise<FieldData | undefined> {
    const data = this.fieldData.get(id);
    if (!data) return undefined;
    
    const updatedData = { ...data, verificationStatus: status };
    this.fieldData.set(id, updatedData);
    return updatedData;
  }

  // Blockchain Pattas implementation
  async getAllBlockchainPattas(): Promise<BlockchainPatta[]> {
    return Array.from(this.blockchainPattas.values());
  }

  async getBlockchainPattaByClaimId(claimId: string): Promise<BlockchainPatta | undefined> {
    return Array.from(this.blockchainPattas.values()).find(patta => patta.claimId === claimId);
  }

  async createBlockchainPatta(insertPatta: InsertBlockchainPatta): Promise<BlockchainPatta> {
    const id = randomUUID();
    const patta: BlockchainPatta = {
      ...insertPatta,
      id,
      timestampCreated: new Date(),
      lastVerified: insertPatta.lastVerified ?? null,
      isValid: insertPatta.isValid ?? true,
      auditTrail: insertPatta.auditTrail ?? null,
      claimId: insertPatta.claimId ?? null,
      smartContractAddress: insertPatta.smartContractAddress ?? null,
      verificationStatus: insertPatta.verificationStatus ?? "pending",
      digitalSignature: insertPatta.digitalSignature ?? null,
      merkleRoot: insertPatta.merkleRoot ?? null,
    };
    this.blockchainPattas.set(id, patta);
    return patta;
  }

  async updateBlockchainPattaVerification(id: string, status: string): Promise<BlockchainPatta | undefined> {
    const patta = this.blockchainPattas.get(id);
    if (!patta) return undefined;
    
    const updatedPatta = { ...patta, verificationStatus: status, lastVerified: new Date() };
    this.blockchainPattas.set(id, updatedPatta);
    return updatedPatta;
  }

  // Drone Data implementation
  async getAllDroneData(): Promise<DroneData[]> {
    return Array.from(this.droneData.values());
  }

  async getDroneDataByVillage(villageId: string): Promise<DroneData[]> {
    return Array.from(this.droneData.values()).filter(drone => drone.villageId === villageId);
  }

  async createDroneData(insertDroneData: InsertDroneData): Promise<DroneData> {
    const id = randomUUID();
    const drone: DroneData = {
      ...insertDroneData,
      id,
      captureTimestamp: new Date(),
      villageId: insertDroneData.villageId ?? null,
      imageUrl: insertDroneData.imageUrl ?? null,
      videoUrl: insertDroneData.videoUrl ?? null,
      batteryLevel: insertDroneData.batteryLevel ?? null,
      weatherConditions: insertDroneData.weatherConditions ?? null,
      aiDetectedObjects: insertDroneData.aiDetectedObjects ?? null,
      anomaliesDetected: insertDroneData.anomaliesDetected ?? null,
      flightStatus: insertDroneData.flightStatus ?? "completed",
      processedBy: insertDroneData.processedBy ?? null,
    };
    this.droneData.set(id, drone);
    return drone;
  }

  async getActiveDrones(): Promise<DroneData[]> {
    return Array.from(this.droneData.values()).filter(drone => drone.flightStatus === "active");
  }

  // Language Translations implementation
  async getTranslationsByLanguage(language: string): Promise<LanguageTranslation[]> {
    return Array.from(this.languageTranslations.values()).filter(trans => trans.language === language);
  }

  async getTranslationByKey(textKey: string, language: string): Promise<LanguageTranslation | undefined> {
    return Array.from(this.languageTranslations.values()).find(trans => 
      trans.textKey === textKey && trans.language === language
    );
  }

  async createTranslation(insertTranslation: InsertLanguageTranslation): Promise<LanguageTranslation> {
    const id = randomUUID();
    const translation: LanguageTranslation = {
      ...insertTranslation,
      id,
      lastUpdated: new Date(),
    };
    this.languageTranslations.set(id, translation);
    return translation;
  }

  // Weather Data implementation
  async getWeatherDataByVillage(villageId: string): Promise<WeatherData[]> {
    return Array.from(this.weatherData.values()).filter(weather => weather.villageId === villageId);
  }

  async getLatestWeatherData(villageId: string): Promise<WeatherData | undefined> {
    const weatherList = Array.from(this.weatherData.values())
      .filter(weather => weather.villageId === villageId)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
    return weatherList[0];
  }

  async createWeatherData(insertWeatherData: InsertWeatherData): Promise<WeatherData> {
    const id = randomUUID();
    const weather: WeatherData = {
      ...insertWeatherData,
      id,
      villageId: insertWeatherData.villageId ?? null,
      temperature: insertWeatherData.temperature ?? null,
      humidity: insertWeatherData.humidity ?? null,
      rainfall: insertWeatherData.rainfall ?? null,
      windSpeed: insertWeatherData.windSpeed ?? null,
      pressure: insertWeatherData.pressure ?? null,
      visibility: insertWeatherData.visibility ?? null,
      uvIndex: insertWeatherData.uvIndex ?? null,
      soilTemperature: insertWeatherData.soilTemperature ?? null,
      evapotranspiration: insertWeatherData.evapotranspiration ?? null,
      dataSource: insertWeatherData.dataSource ?? null,
      forecastData: insertWeatherData.forecastData ?? null,
    };
    this.weatherData.set(id, weather);
    return weather;
  }

  // Predictive Models implementation
  async getAllPredictiveModels(): Promise<PredictiveModel[]> {
    return Array.from(this.predictiveModels.values());
  }

  async getActiveModel(modelType: string): Promise<PredictiveModel | undefined> {
    return Array.from(this.predictiveModels.values()).find(model => 
      model.modelType === modelType && model.isActive
    );
  }

  async createPredictiveModel(insertModel: InsertPredictiveModel): Promise<PredictiveModel> {
    const id = randomUUID();
    const model: PredictiveModel = {
      ...insertModel,
      id,
      trainingDate: new Date(),
      isActive: insertModel.isActive ?? false,
      trainingDataSize: insertModel.trainingDataSize ?? null,
      accuracy: insertModel.accuracy ?? null,
      precision: insertModel.precision ?? null,
      recall: insertModel.recall ?? null,
      f1Score: insertModel.f1Score ?? null,
      hyperparameters: insertModel.hyperparameters ?? null,
      featureImportance: insertModel.featureImportance ?? null,
      crossValidationScore: insertModel.crossValidationScore ?? null,
      features: insertModel.features ?? null,
    };
    this.predictiveModels.set(id, model);
    return model;
  }

  // Anomaly Detection implementation
  async getAllAnomalies(): Promise<AnomalyDetection[]> {
    return Array.from(this.anomalies.values());
  }

  async getAnomaliesByVillage(villageId: string): Promise<AnomalyDetection[]> {
    return Array.from(this.anomalies.values()).filter(anomaly => anomaly.villageId === villageId);
  }

  async getAnomaliesBySeverity(severity: string): Promise<AnomalyDetection[]> {
    return Array.from(this.anomalies.values()).filter(anomaly => anomaly.severity === severity);
  }

  async createAnomaly(insertAnomaly: InsertAnomalyDetection): Promise<AnomalyDetection> {
    const id = randomUUID();
    const anomaly: AnomalyDetection = {
      ...insertAnomaly,
      id,
      detectedAt: new Date(),
      resolvedAt: insertAnomaly.resolvedAt ?? null,
      villageId: insertAnomaly.villageId ?? null,
      description: insertAnomaly.description ?? null,
      verificationStatus: insertAnomaly.verificationStatus ?? "pending",
      actionTaken: insertAnomaly.actionTaken ?? null,
      estimatedDamage: insertAnomaly.estimatedDamage ?? null,
      evidenceUrls: insertAnomaly.evidenceUrls ?? null,
      alertsSent: insertAnomaly.alertsSent ?? null,
    };
    this.anomalies.set(id, anomaly);
    return anomaly;
  }

  // Citizen Reports implementation
  async getAllCitizenReports(): Promise<CitizenReport[]> {
    return Array.from(this.citizenReports.values());
  }

  async getCitizenReportsByUser(citizenId: string): Promise<CitizenReport[]> {
    return Array.from(this.citizenReports.values()).filter(report => report.citizenId === citizenId);
  }

  async getPublicCitizenReports(): Promise<CitizenReport[]> {
    return Array.from(this.citizenReports.values()).filter(report => report.publiclyVisible);
  }

  async createCitizenReport(insertReport: InsertCitizenReport): Promise<CitizenReport> {
    const id = randomUUID();
    const report: CitizenReport = {
      ...insertReport,
      id,
      submittedAt: new Date(),
      verifiedAt: insertReport.verifiedAt ?? null,
      citizenId: insertReport.citizenId ?? null,
      villageId: insertReport.villageId ?? null,
      location: insertReport.location ?? null,
      photos: insertReport.photos ?? null,
      severity: insertReport.severity ?? "medium",
      status: insertReport.status ?? "submitted",
      verifiedBy: insertReport.verifiedBy ?? null,
      gamificationPoints: insertReport.gamificationPoints ?? 0,
      publiclyVisible: insertReport.publiclyVisible ?? false,
    };
    this.citizenReports.set(id, report);
    return report;
  }

  async updateCitizenReportStatus(id: string, status: string): Promise<CitizenReport | undefined> {
    const report = this.citizenReports.get(id);
    if (!report) return undefined;
    
    const updatedReport = { ...report, status };
    this.citizenReports.set(id, updatedReport);
    return updatedReport;
  }

  // Scenario Simulations implementation
  async getAllSimulations(): Promise<ScenarioSimulation[]> {
    return Array.from(this.scenarioSimulations.values());
  }

  async getSimulationsByUser(userId: string): Promise<ScenarioSimulation[]> {
    return Array.from(this.scenarioSimulations.values()).filter(sim => sim.createdBy === userId);
  }

  async createSimulation(insertSimulation: InsertScenarioSimulation): Promise<ScenarioSimulation> {
    const id = randomUUID();
    const simulation: ScenarioSimulation = {
      ...insertSimulation,
      id,
      createdAt: new Date(),
      createdBy: insertSimulation.createdBy ?? null,
      inputParameters: insertSimulation.inputParameters ?? null,
      targetVillages: insertSimulation.targetVillages ?? null,
      timeframe: insertSimulation.timeframe ?? null,
      predictedOutcomes: insertSimulation.predictedOutcomes ?? null,
      confidenceInterval: insertSimulation.confidenceInterval ?? null,
      simulationStatus: insertSimulation.simulationStatus ?? "completed",
    };
    this.scenarioSimulations.set(id, simulation);
    return simulation;
  }
}

export const storage = new MemStorage();
