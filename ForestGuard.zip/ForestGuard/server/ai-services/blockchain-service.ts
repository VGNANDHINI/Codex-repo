import { BlockchainPatta, Claim, InsertBlockchainPatta } from "../../shared/schema.js";
import { createHash } from "crypto";

export interface BlockchainTransaction {
  transactionId: string;
  blockHash: string;
  timestamp: Date;
  gasUsed: number;
  status: 'pending' | 'confirmed' | 'failed';
}

export interface SmartContractEvent {
  eventName: string;
  parameters: Record<string, any>;
  blockNumber: number;
  transactionHash: string;
}

export interface VerificationResult {
  isValid: boolean;
  onChain: boolean;
  verificationScore: number;
  lastVerified: Date;
  discrepancies: string[];
}

export class BlockchainService {
  private networkConfig = {
    rpcUrl: process.env.BLOCKCHAIN_RPC_URL || "https://rpc.polygon.technology",
    chainId: 137, // Polygon Mainnet
    contractAddress: process.env.SMART_CONTRACT_ADDRESS || "0x1234567890123456789012345678901234567890"
  };

  private isConnected = false;

  async initialize() {
    if (this.isConnected) return;
    
    try {
      // In production, this would connect to actual blockchain network
      console.log(`Connecting to blockchain network: ${this.networkConfig.chainId}`);
      this.isConnected = true;
    } catch (error) {
      console.error("Failed to connect to blockchain:", error);
      throw new Error("Blockchain connection failed");
    }
  }

  async createPattaRecord(claimData: Claim): Promise<BlockchainPatta> {
    await this.initialize();

    // Generate unique blockchain hash for the patta
    const pattaData = {
      claimId: claimData.id,
      claimantName: claimData.claimantName,
      claimType: claimData.claimType,
      area: claimData.area,
      applicationId: claimData.applicationId,
      timestamp: new Date().toISOString()
    };

    const blockchainHash = this.generateBlockchainHash(pattaData);
    const transactionId = this.generateTransactionId();

    // Create smart contract transaction
    const transaction = await this.deployPattaContract(pattaData, blockchainHash);

    // Generate digital signature
    const digitalSignature = this.generateDigitalSignature(pattaData);

    // Calculate Merkle root for batch verification
    const merkleRoot = this.calculateMerkleRoot([blockchainHash]);

    const blockchainPatta: Omit<BlockchainPatta, 'id' | 'timestampCreated'> = {
      claimId: claimData.id,
      blockchainHash,
      transactionId,
      smartContractAddress: this.networkConfig.contractAddress,
      verificationStatus: 'pending',
      digitalSignature,
      merkleRoot,
      lastVerified: null,
      isValid: true,
      auditTrail: {
        changes: [{
          timestamp: new Date().toISOString(),
          field: 'initial_creation',
          oldValue: '',
          newValue: 'patta_created',
          authorizedBy: 'system'
        }]
      }
    };

    return blockchainPatta as BlockchainPatta;
  }

  async verifyPatta(blockchainPatta: BlockchainPatta): Promise<VerificationResult> {
    await this.initialize();

    const verificationResult: VerificationResult = {
      isValid: true,
      onChain: true,
      verificationScore: 100,
      lastVerified: new Date(),
      discrepancies: []
    };

    try {
      // 1. Verify blockchain hash integrity
      const hashVerification = await this.verifyBlockchainHash(blockchainPatta.blockchainHash);
      if (!hashVerification.valid) {
        verificationResult.isValid = false;
        verificationResult.verificationScore -= 30;
        verificationResult.discrepancies.push("Blockchain hash verification failed");
      }

      // 2. Verify transaction on blockchain
      const transactionVerification = await this.verifyTransaction(blockchainPatta.transactionId);
      if (!transactionVerification.exists) {
        verificationResult.onChain = false;
        verificationResult.verificationScore -= 40;
        verificationResult.discrepancies.push("Transaction not found on blockchain");
      }

      // 3. Verify digital signature
      const signatureVerification = this.verifyDigitalSignature(
        blockchainPatta.digitalSignature,
        blockchainPatta.blockchainHash
      );
      if (!signatureVerification.valid) {
        verificationResult.isValid = false;
        verificationResult.verificationScore -= 20;
        verificationResult.discrepancies.push("Digital signature verification failed");
      }

      // 4. Verify Merkle proof
      const merkleVerification = this.verifyMerkleProof(
        blockchainPatta.blockchainHash,
        blockchainPatta.merkleRoot
      );
      if (!merkleVerification.valid) {
        verificationResult.verificationScore -= 10;
        verificationResult.discrepancies.push("Merkle proof verification failed");
      }

      // 5. Check smart contract state
      const contractVerification = await this.verifySmartContractState(
        blockchainPatta.smartContractAddress,
        blockchainPatta.claimId
      );
      if (!contractVerification.valid) {
        verificationResult.verificationScore -= 20;
        verificationResult.discrepancies.push("Smart contract state mismatch");
      }

    } catch (error) {
      verificationResult.isValid = false;
      verificationResult.verificationScore = 0;
      verificationResult.discrepancies.push(`Verification error: ${error}`);
    }

    return verificationResult;
  }

  async updatePattaRecord(
    blockchainPatta: BlockchainPatta,
    updates: Partial<Claim>,
    authorizedBy: string
  ): Promise<BlockchainPatta> {
    await this.initialize();

    // Create audit trail entry
    const auditEntry = {
      timestamp: new Date().toISOString(),
      field: Object.keys(updates).join(','),
      oldValue: 'previous_values',
      newValue: JSON.stringify(updates),
      authorizedBy
    };

    // Update audit trail
    const updatedAuditTrail = {
      changes: [
        ...(blockchainPatta.auditTrail?.changes || []),
        auditEntry
      ]
    };

    // Generate new blockchain hash for the update
    const updateData = {
      ...updates,
      previousHash: blockchainPatta.blockchainHash,
      updateTimestamp: new Date().toISOString(),
      authorizedBy
    };

    const newBlockchainHash = this.generateBlockchainHash(updateData);
    const updateTransactionId = this.generateTransactionId();

    // Deploy update transaction to blockchain
    await this.deployUpdateTransaction(updateData, newBlockchainHash);

    // Generate new digital signature
    const newDigitalSignature = this.generateDigitalSignature(updateData);

    const updatedPatta: BlockchainPatta = {
      ...blockchainPatta,
      blockchainHash: newBlockchainHash,
      transactionId: updateTransactionId,
      digitalSignature: newDigitalSignature,
      lastVerified: new Date(),
      auditTrail: updatedAuditTrail,
      verificationStatus: 'pending'
    };

    return updatedPatta;
  }

  async batchVerifyPattas(pattas: BlockchainPatta[]): Promise<VerificationResult[]> {
    await this.initialize();

    const results: VerificationResult[] = [];
    
    // Process in batches of 10 for efficiency
    const batchSize = 10;
    for (let i = 0; i < pattas.length; i += batchSize) {
      const batch = pattas.slice(i, i + batchSize);
      
      const batchPromises = batch.map(patta => this.verifyPatta(patta));
      const batchResults = await Promise.all(batchPromises);
      
      results.push(...batchResults);
    }

    return results;
  }

  async getAuditTrail(blockchainPatta: BlockchainPatta): Promise<{
    onChainEvents: SmartContractEvent[];
    localAuditTrail: Array<{
      timestamp: string;
      field: string;
      oldValue: string;
      newValue: string;
      authorizedBy: string;
    }>;
    verificationHistory: Array<{
      verifiedAt: Date;
      result: VerificationResult;
    }>;
  }> {
    await this.initialize();

    // Get smart contract events
    const onChainEvents = await this.getSmartContractEvents(
      blockchainPatta.smartContractAddress,
      blockchainPatta.claimId
    );

    // Get local audit trail
    const localAuditTrail = blockchainPatta.auditTrail?.changes || [];

    // Mock verification history (in production, this would be stored)
    const verificationHistory = [
      {
        verifiedAt: blockchainPatta.lastVerified || new Date(),
        result: await this.verifyPatta(blockchainPatta)
      }
    ];

    return {
      onChainEvents,
      localAuditTrail,
      verificationHistory
    };
  }

  // Smart contract automated eligibility checking
  async checkSchemeEligibility(
    claimData: Claim,
    schemeId: string
  ): Promise<{
    eligible: boolean;
    confidence: number;
    requirements: Array<{
      requirement: string;
      met: boolean;
      value: any;
    }>;
    autoApprovalPossible: boolean;
  }> {
    await this.initialize();

    // Define eligibility criteria (would be from smart contract)
    const eligibilityCriteria = this.getSchemeEligibilityCriteria(schemeId);
    
    const requirements = eligibilityCriteria.map(criteria => ({
      requirement: criteria.name,
      met: this.evaluateRequirement(claimData, criteria),
      value: this.extractRequirementValue(claimData, criteria)
    }));

    const metRequirements = requirements.filter(req => req.met).length;
    const totalRequirements = requirements.length;
    
    const confidence = (metRequirements / totalRequirements) * 100;
    const eligible = confidence >= 80; // 80% threshold
    const autoApprovalPossible = confidence >= 95; // 95% for auto-approval

    return {
      eligible,
      confidence,
      requirements,
      autoApprovalPossible
    };
  }

  // Private helper methods
  private generateBlockchainHash(data: any): string {
    const dataString = JSON.stringify(data, Object.keys(data).sort());
    return createHash('sha256').update(dataString).digest('hex');
  }

  private generateTransactionId(): string {
    return '0x' + createHash('sha256')
      .update(Date.now().toString() + Math.random().toString())
      .digest('hex')
      .substring(0, 64);
  }

  private generateDigitalSignature(data: any): string {
    // In production, this would use proper cryptographic signing
    const dataHash = this.generateBlockchainHash(data);
    return createHash('sha256').update(dataHash + 'DIGITAL_SIGNATURE_KEY').digest('hex');
  }

  private calculateMerkleRoot(hashes: string[]): string {
    if (hashes.length === 0) return '';
    if (hashes.length === 1) return hashes[0];
    
    const nextLevel: string[] = [];
    for (let i = 0; i < hashes.length; i += 2) {
      const left = hashes[i];
      const right = hashes[i + 1] || hashes[i];
      const combined = createHash('sha256').update(left + right).digest('hex');
      nextLevel.push(combined);
    }
    
    return this.calculateMerkleRoot(nextLevel);
  }

  private async deployPattaContract(data: any, hash: string): Promise<BlockchainTransaction> {
    // Mock blockchain deployment
    return {
      transactionId: this.generateTransactionId(),
      blockHash: createHash('sha256').update(hash).digest('hex'),
      timestamp: new Date(),
      gasUsed: 21000,
      status: 'confirmed'
    };
  }

  private async deployUpdateTransaction(data: any, hash: string): Promise<BlockchainTransaction> {
    // Mock blockchain update transaction
    return {
      transactionId: this.generateTransactionId(),
      blockHash: createHash('sha256').update(hash).digest('hex'),
      timestamp: new Date(),
      gasUsed: 15000,
      status: 'confirmed'
    };
  }

  private async verifyBlockchainHash(hash: string): Promise<{ valid: boolean; onChain: boolean }> {
    // Mock hash verification
    return {
      valid: hash.length === 64 && /^[a-f0-9]+$/i.test(hash),
      onChain: true
    };
  }

  private async verifyTransaction(transactionId: string): Promise<{ exists: boolean; confirmed: boolean }> {
    // Mock transaction verification
    return {
      exists: transactionId.startsWith('0x') && transactionId.length === 66,
      confirmed: true
    };
  }

  private verifyDigitalSignature(signature: string, hash: string): { valid: boolean } {
    // Mock signature verification
    const expectedSignature = createHash('sha256').update(hash + 'DIGITAL_SIGNATURE_KEY').digest('hex');
    return {
      valid: signature === expectedSignature
    };
  }

  private verifyMerkleProof(hash: string, merkleRoot: string): { valid: boolean } {
    // Mock Merkle proof verification
    return {
      valid: merkleRoot.includes(hash.substring(0, 8))
    };
  }

  private async verifySmartContractState(contractAddress: string, claimId: string): Promise<{ valid: boolean }> {
    // Mock smart contract state verification
    return {
      valid: contractAddress === this.networkConfig.contractAddress
    };
  }

  private async getSmartContractEvents(contractAddress: string, claimId: string): Promise<SmartContractEvent[]> {
    // Mock smart contract events
    return [
      {
        eventName: 'PattaCreated',
        parameters: { claimId, timestamp: new Date().toISOString() },
        blockNumber: 12345,
        transactionHash: this.generateTransactionId()
      }
    ];
  }

  private getSchemeEligibilityCriteria(schemeId: string): Array<{
    name: string;
    type: 'numeric' | 'boolean' | 'string';
    condition: any;
  }> {
    // Mock eligibility criteria
    const criteriaMap: Record<string, any[]> = {
      'PM-KISAN': [
        { name: 'landOwnership', type: 'boolean', condition: true },
        { name: 'farmSize', type: 'numeric', condition: { operator: '<=', value: 2 } },
        { name: 'claimType', type: 'string', condition: 'IFR' }
      ],
      'MGNREGA': [
        { name: 'ruralResident', type: 'boolean', condition: true },
        { name: 'adultWorkers', type: 'numeric', condition: { operator: '>=', value: 1 } }
      ]
    };
    
    return criteriaMap[schemeId] || [];
  }

  private evaluateRequirement(claimData: Claim, criteria: any): boolean {
    // Mock requirement evaluation
    switch (criteria.name) {
      case 'landOwnership':
        return claimData.claimType === 'IFR';
      case 'farmSize':
        return (claimData.area || 0) <= criteria.condition.value;
      case 'claimType':
        return claimData.claimType === criteria.condition;
      default:
        return true;
    }
  }

  private extractRequirementValue(claimData: Claim, criteria: any): any {
    switch (criteria.name) {
      case 'landOwnership':
        return claimData.claimType === 'IFR';
      case 'farmSize':
        return claimData.area;
      case 'claimType':
        return claimData.claimType;
      default:
        return null;
    }
  }
}

export const blockchainService = new BlockchainService();