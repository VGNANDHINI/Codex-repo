import { Village, SatelliteImage, DroneData, IotSensor, AnomalyDetection } from "../../shared/schema.js";

export interface AnomalyResult {
  type: 'illegal_logging' | 'mining' | 'encroachment' | 'land_use_change' | 'pollution';
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  location: {
    latitude: number;
    longitude: number;
    area?: number;
    boundingBox?: [number, number, number, number];
  };
  description: string;
  evidenceUrls: string[];
  detectionMethod: 'satellite' | 'drone' | 'IoT' | 'citizen_report';
  metadata: Record<string, any>;
}

export interface ChangeDetectionResult {
  changedAreas: Array<{
    coordinates: [number, number];
    changeType: string;
    magnitude: number;
    confidence: number;
  }>;
  overallChangeScore: number;
  forestLoss: number;
  newConstructions: number;
  waterBodyChanges: number;
}

export class AnomalyDetectionService {
  private thresholds = {
    forestLossThreshold: 0.15, // 15% forest loss triggers alert
    newConstructionThreshold: 0.05, // 5% new construction
    waterQualityThreshold: 6.5, // pH below 6.5 or above 8.5
    airQualityThreshold: 100, // AQI above 100
    temperatureAnomalyThreshold: 5, // 5°C above/below seasonal average
    vegetationHealthThreshold: 0.3 // NDVI drop of 30%
  };

  async detectSatelliteAnomalies(
    currentImagery: SatelliteImage[],
    historicalImagery: SatelliteImage[],
    village: Village
  ): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    // 1. Forest Cover Change Detection
    const forestAnomalies = await this.detectForestChanges(currentImagery, historicalImagery, village);
    anomalies.push(...forestAnomalies);

    // 2. Land Use Change Detection
    const landUseAnomalies = await this.detectLandUseChanges(currentImagery, historicalImagery, village);
    anomalies.push(...landUseAnomalies);

    // 3. Water Body Changes
    const waterAnomalies = await this.detectWaterBodyChanges(currentImagery, historicalImagery, village);
    anomalies.push(...waterAnomalies);

    // 4. Unauthorized Construction Detection
    const constructionAnomalies = await this.detectUnauthorizedConstruction(currentImagery, historicalImagery, village);
    anomalies.push(...constructionAnomalies);

    return anomalies;
  }

  async detectDroneAnomalies(droneData: DroneData[], village: Village): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    for (const drone of droneData) {
      // Process AI-detected objects for anomalies
      if (drone.aiDetectedObjects) {
        for (const obj of drone.aiDetectedObjects) {
          if (this.isAnomalousObject(obj)) {
            anomalies.push({
              type: this.classifyObjectAnomaly(obj.objectType),
              severity: this.calculateSeverity(obj.confidence, obj.objectType),
              confidence: obj.confidence,
              location: {
                latitude: obj.coordinates[0],
                longitude: obj.coordinates[1]
              },
              description: `Detected ${obj.objectType} with ${(obj.confidence * 100).toFixed(1)}% confidence`,
              evidenceUrls: [drone.imageUrl, drone.videoUrl].filter(Boolean) as string[],
              detectionMethod: 'drone',
              metadata: {
                droneId: drone.droneId,
                captureTime: drone.captureTimestamp,
                boundingBox: obj.boundingBox
              }
            });
          }
        }
      }

      // Process directly detected anomalies
      if (drone.anomaliesDetected) {
        for (const anomaly of drone.anomaliesDetected) {
          anomalies.push({
            type: anomaly.type as any,
            severity: anomaly.severity as any,
            confidence: anomaly.confidence,
            location: {
              latitude: anomaly.location[0],
              longitude: anomaly.location[1]
            },
            description: anomaly.description,
            evidenceUrls: [drone.imageUrl, drone.videoUrl].filter(Boolean) as string[],
            detectionMethod: 'drone',
            metadata: {
              droneId: drone.droneId,
              captureTime: drone.captureTimestamp
            }
          });
        }
      }
    }

    return anomalies;
  }

  async detectIoTAnomalies(iotData: IotSensor[], village: Village): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    // Group IoT data by sensor type
    const sensorGroups = this.groupBySensorType(iotData);

    // Water Quality Anomalies
    if (sensorGroups.water_quality) {
      const waterAnomalies = this.analyzeWaterQuality(sensorGroups.water_quality, village);
      anomalies.push(...waterAnomalies);
    }

    // Air Quality Anomalies
    if (sensorGroups.air_quality) {
      const airAnomalies = this.analyzeAirQuality(sensorGroups.air_quality, village);
      anomalies.push(...airAnomalies);
    }

    // Soil Moisture Anomalies
    if (sensorGroups.soil_moisture) {
      const soilAnomalies = this.analyzeSoilConditions(sensorGroups.soil_moisture, village);
      anomalies.push(...soilAnomalies);
    }

    // Forest Health Anomalies
    if (sensorGroups.forest_health) {
      const forestAnomalies = this.analyzeForestHealth(sensorGroups.forest_health, village);
      anomalies.push(...forestAnomalies);
    }

    return anomalies;
  }

  private async detectForestChanges(
    current: SatelliteImage[],
    historical: SatelliteImage[],
    village: Village
  ): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    if (current.length === 0 || historical.length === 0) return anomalies;

    const currentForestCover = this.calculateAverageForestCover(current);
    const historicalForestCover = this.calculateAverageForestCover(historical);
    
    const forestLossPercentage = (historicalForestCover - currentForestCover) / historicalForestCover;

    if (forestLossPercentage > this.thresholds.forestLossThreshold) {
      const severity = this.calculateForestLossSeverity(forestLossPercentage);
      
      anomalies.push({
        type: 'illegal_logging',
        severity,
        confidence: 0.85,
        location: {
          latitude: village.latitude,
          longitude: village.longitude,
          area: forestLossPercentage * (village.assets?.forestCover || 0)
        },
        description: `Significant forest loss detected: ${(forestLossPercentage * 100).toFixed(1)}% decrease in forest cover`,
        evidenceUrls: current.map(img => img.imageUrl),
        detectionMethod: 'satellite',
        metadata: {
          forestLossPercentage,
          currentCover: currentForestCover,
          historicalCover: historicalForestCover,
          analysisPeriod: this.getAnalysisPeriod(current, historical)
        }
      });
    }

    return anomalies;
  }

  private async detectLandUseChanges(
    current: SatelliteImage[],
    historical: SatelliteImage[],
    village: Village
  ): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    const changeDetection = this.performChangeDetection(current, historical);
    
    if (changeDetection.overallChangeScore > 0.2) { // 20% change threshold
      anomalies.push({
        type: 'land_use_change',
        severity: changeDetection.overallChangeScore > 0.5 ? 'high' : 'medium',
        confidence: 0.75,
        location: {
          latitude: village.latitude,
          longitude: village.longitude,
          area: changeDetection.overallChangeScore * (village.forestArea || 0)
        },
        description: `Significant land use change detected: ${(changeDetection.overallChangeScore * 100).toFixed(1)}% area affected`,
        evidenceUrls: current.map(img => img.imageUrl),
        detectionMethod: 'satellite',
        metadata: {
          changeDetails: changeDetection,
          analysisType: 'land_use_change_detection'
        }
      });
    }

    return anomalies;
  }

  private async detectWaterBodyChanges(
    current: SatelliteImage[],
    historical: SatelliteImage[],
    village: Village
  ): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    const currentWaterCover = this.calculateAverageWaterCover(current);
    const historicalWaterCover = this.calculateAverageWaterCover(historical);
    
    const waterChangePercentage = Math.abs(currentWaterCover - historicalWaterCover) / historicalWaterCover;

    if (waterChangePercentage > 0.3) { // 30% change in water bodies
      anomalies.push({
        type: 'land_use_change',
        severity: waterChangePercentage > 0.6 ? 'high' : 'medium',
        confidence: 0.80,
        location: {
          latitude: village.latitude,
          longitude: village.longitude,
          area: waterChangePercentage * (village.assets?.waterBodies || 0)
        },
        description: `Significant water body changes: ${currentWaterCover > historicalWaterCover ? 'increase' : 'decrease'} of ${(waterChangePercentage * 100).toFixed(1)}%`,
        evidenceUrls: current.map(img => img.imageUrl),
        detectionMethod: 'satellite',
        metadata: {
          waterChangePercentage,
          currentWaterCover,
          historicalWaterCover,
          changeType: currentWaterCover > historicalWaterCover ? 'increase' : 'decrease'
        }
      });
    }

    return anomalies;
  }

  private async detectUnauthorizedConstruction(
    current: SatelliteImage[],
    historical: SatelliteImage[],
    village: Village
  ): Promise<AnomalyResult[]> {
    const anomalies: AnomalyResult[] = [];

    const currentBuiltUp = this.calculateAverageBuiltUpArea(current);
    const historicalBuiltUp = this.calculateAverageBuiltUpArea(historical);
    
    const constructionIncrease = (currentBuiltUp - historicalBuiltUp) / historicalBuiltUp;

    if (constructionIncrease > this.thresholds.newConstructionThreshold) {
      anomalies.push({
        type: 'encroachment',
        severity: constructionIncrease > 0.15 ? 'high' : 'medium',
        confidence: 0.70,
        location: {
          latitude: village.latitude,
          longitude: village.longitude,
          area: constructionIncrease * (village.assets?.infrastructure || 0)
        },
        description: `Unauthorized construction detected: ${(constructionIncrease * 100).toFixed(1)}% increase in built-up area`,
        evidenceUrls: current.map(img => img.imageUrl),
        detectionMethod: 'satellite',
        metadata: {
          constructionIncrease,
          currentBuiltUp,
          historicalBuiltUp,
          possibleEncroachment: true
        }
      });
    }

    return anomalies;
  }

  private analyzeWaterQuality(sensors: IotSensor[], village: Village): AnomalyResult[] {
    const anomalies: AnomalyResult[] = [];

    for (const sensor of sensors) {
      const ph = sensor.readings?.pH;
      const waterQuality = sensor.readings?.waterQuality;

      if (ph && (ph < 6.5 || ph > 8.5)) {
        anomalies.push({
          type: 'pollution',
          severity: ph < 6 || ph > 9 ? 'high' : 'medium',
          confidence: 0.90,
          location: {
            latitude: sensor.latitude,
            longitude: sensor.longitude
          },
          description: `Water pH anomaly detected: ${ph.toFixed(2)} (normal range: 6.5-8.5)`,
          evidenceUrls: [],
          detectionMethod: 'IoT',
          metadata: {
            sensorId: sensor.sensorId,
            pH: ph,
            measurementTime: sensor.timestamp,
            waterQuality
          }
        });
      }

      if (waterQuality && waterQuality < 50) { // Water quality index below 50
        anomalies.push({
          type: 'pollution',
          severity: waterQuality < 25 ? 'critical' : 'high',
          confidence: 0.85,
          location: {
            latitude: sensor.latitude,
            longitude: sensor.longitude
          },
          description: `Poor water quality detected: Index ${waterQuality.toFixed(1)} (critical below 50)`,
          evidenceUrls: [],
          detectionMethod: 'IoT',
          metadata: {
            sensorId: sensor.sensorId,
            waterQualityIndex: waterQuality,
            measurementTime: sensor.timestamp
          }
        });
      }
    }

    return anomalies;
  }

  private analyzeAirQuality(sensors: IotSensor[], village: Village): AnomalyResult[] {
    const anomalies: AnomalyResult[] = [];

    for (const sensor of sensors) {
      const airQuality = sensor.readings?.airQuality;
      const co2Level = sensor.readings?.co2Level;

      if (airQuality && airQuality > this.thresholds.airQualityThreshold) {
        anomalies.push({
          type: 'pollution',
          severity: airQuality > 200 ? 'critical' : airQuality > 150 ? 'high' : 'medium',
          confidence: 0.88,
          location: {
            latitude: sensor.latitude,
            longitude: sensor.longitude
          },
          description: `Poor air quality detected: AQI ${airQuality.toFixed(1)} (unhealthy above 100)`,
          evidenceUrls: [],
          detectionMethod: 'IoT',
          metadata: {
            sensorId: sensor.sensorId,
            airQualityIndex: airQuality,
            co2Level,
            measurementTime: sensor.timestamp
          }
        });
      }
    }

    return anomalies;
  }

  private analyzeSoilConditions(sensors: IotSensor[], village: Village): AnomalyResult[] {
    const anomalies: AnomalyResult[] = [];

    for (const sensor of sensors) {
      const soilMoisture = sensor.readings?.soilMoisture;
      const temperature = sensor.readings?.temperature;

      if (soilMoisture && soilMoisture < 20) { // Very dry soil
        anomalies.push({
          type: 'land_use_change',
          severity: soilMoisture < 10 ? 'critical' : 'high',
          confidence: 0.82,
          location: {
            latitude: sensor.latitude,
            longitude: sensor.longitude
          },
          description: `Critically low soil moisture: ${soilMoisture.toFixed(1)}% (drought conditions)`,
          evidenceUrls: [],
          detectionMethod: 'IoT',
          metadata: {
            sensorId: sensor.sensorId,
            soilMoisture,
            temperature,
            droughtRisk: true,
            measurementTime: sensor.timestamp
          }
        });
      }
    }

    return anomalies;
  }

  private analyzeForestHealth(sensors: IotSensor[], village: Village): AnomalyResult[] {
    const anomalies: AnomalyResult[] = [];

    for (const sensor of sensors) {
      const temperature = sensor.readings?.temperature;
      const humidity = sensor.readings?.humidity;

      if (temperature && temperature > 45) { // Extreme heat
        anomalies.push({
          type: 'land_use_change',
          severity: 'high',
          confidence: 0.75,
          location: {
            latitude: sensor.latitude,
            longitude: sensor.longitude
          },
          description: `Extreme temperature detected in forest area: ${temperature.toFixed(1)}°C`,
          evidenceUrls: [],
          detectionMethod: 'IoT',
          metadata: {
            sensorId: sensor.sensorId,
            temperature,
            humidity,
            heatStress: true,
            measurementTime: sensor.timestamp
          }
        });
      }
    }

    return anomalies;
  }

  // Helper methods
  private groupBySensorType(iotData: IotSensor[]): Record<string, IotSensor[]> {
    return iotData.reduce((groups, sensor) => {
      const type = sensor.sensorType;
      if (!groups[type]) groups[type] = [];
      groups[type].push(sensor);
      return groups;
    }, {} as Record<string, IotSensor[]>);
  }

  private calculateAverageForestCover(images: SatelliteImage[]): number {
    return images.reduce((sum, img) => sum + (img.processedData?.forestCover || 0), 0) / images.length;
  }

  private calculateAverageWaterCover(images: SatelliteImage[]): number {
    return images.reduce((sum, img) => sum + (img.processedData?.waterBodies || 0), 0) / images.length;
  }

  private calculateAverageBuiltUpArea(images: SatelliteImage[]): number {
    return images.reduce((sum, img) => sum + (img.processedData?.builtUpArea || 0), 0) / images.length;
  }

  private performChangeDetection(current: SatelliteImage[], historical: SatelliteImage[]): ChangeDetectionResult {
    const currentAvg = this.calculateImageAverages(current);
    const historicalAvg = this.calculateImageAverages(historical);

    const forestLoss = Math.max(0, historicalAvg.forestCover - currentAvg.forestCover);
    const newConstructions = Math.max(0, currentAvg.builtUpArea - historicalAvg.builtUpArea);
    const waterBodyChanges = Math.abs(currentAvg.waterBodies - historicalAvg.waterBodies);

    const overallChangeScore = (forestLoss + newConstructions + waterBodyChanges) / 3 / 100; // Normalize

    return {
      changedAreas: [], // Would be populated with actual coordinate analysis
      overallChangeScore,
      forestLoss,
      newConstructions,
      waterBodyChanges
    };
  }

  private calculateImageAverages(images: SatelliteImage[]) {
    const totals = images.reduce((sum, img) => ({
      forestCover: sum.forestCover + (img.processedData?.forestCover || 0),
      builtUpArea: sum.builtUpArea + (img.processedData?.builtUpArea || 0),
      waterBodies: sum.waterBodies + (img.processedData?.waterBodies || 0),
      agriculturalArea: sum.agriculturalArea + (img.processedData?.agriculturalArea || 0)
    }), { forestCover: 0, builtUpArea: 0, waterBodies: 0, agriculturalArea: 0 });

    return {
      forestCover: totals.forestCover / images.length,
      builtUpArea: totals.builtUpArea / images.length,
      waterBodies: totals.waterBodies / images.length,
      agriculturalArea: totals.agriculturalArea / images.length
    };
  }

  private isAnomalousObject(obj: any): boolean {
    const anomalousTypes = ['illegal_logging', 'mining_equipment', 'unauthorized_structure', 'dumping_site'];
    return anomalousTypes.includes(obj.objectType) || obj.confidence > 0.8;
  }

  private classifyObjectAnomaly(objectType: string): AnomalyResult['type'] {
    const typeMap: Record<string, AnomalyResult['type']> = {
      'illegal_logging': 'illegal_logging',
      'mining_equipment': 'mining',
      'unauthorized_structure': 'encroachment',
      'dumping_site': 'pollution',
      'vehicle': 'encroachment'
    };
    return typeMap[objectType] || 'land_use_change';
  }

  private calculateSeverity(confidence: number, objectType: string): AnomalyResult['severity'] {
    if (confidence > 0.9) return 'critical';
    if (confidence > 0.8) return 'high';
    if (confidence > 0.6) return 'medium';
    return 'low';
  }

  private calculateForestLossSeverity(lossPercentage: number): AnomalyResult['severity'] {
    if (lossPercentage > 0.5) return 'critical';
    if (lossPercentage > 0.3) return 'high';
    if (lossPercentage > 0.15) return 'medium';
    return 'low';
  }

  private getAnalysisPeriod(current: SatelliteImage[], historical: SatelliteImage[]): string {
    const currentDate = new Date(Math.max(...current.map(img => new Date(img.captureDate).getTime())));
    const historicalDate = new Date(Math.min(...historical.map(img => new Date(img.captureDate).getTime())));
    
    const diffMonths = (currentDate.getTime() - historicalDate.getTime()) / (1000 * 60 * 60 * 24 * 30);
    return `${Math.round(diffMonths)} months`;
  }

  // Batch processing for multiple villages
  async processVillageBatch(
    villages: Village[],
    satelliteData: SatelliteImage[],
    droneData: DroneData[],
    iotData: IotSensor[]
  ): Promise<Array<{ villageId: string; anomalies: AnomalyResult[] }>> {
    const results: Array<{ villageId: string; anomalies: AnomalyResult[] }> = [];

    for (const village of villages) {
      const villageSatellite = satelliteData.filter(s => s.villageId === village.id);
      const villageDrone = droneData.filter(d => d.villageId === village.id);
      const villageIoT = iotData.filter(i => i.villageId === village.id);

      const current = villageSatellite.slice(-5); // Last 5 images
      const historical = villageSatellite.slice(-15, -5); // Previous 10 images

      const satelliteAnomalies = await this.detectSatelliteAnomalies(current, historical, village);
      const droneAnomalies = await this.detectDroneAnomalies(villageDrone, village);
      const iotAnomalies = await this.detectIoTAnomalies(villageIoT, village);

      const allAnomalies = [...satelliteAnomalies, ...droneAnomalies, ...iotAnomalies];
      
      results.push({
        villageId: village.id,
        anomalies: allAnomalies
      });
    }

    return results;
  }
}

export const anomalyDetectionService = new AnomalyDetectionService();