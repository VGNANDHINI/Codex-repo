import { createWorker } from 'tesseract.js';
// import pdfParse from 'pdf-parse';
import natural from 'natural';
import nlp from 'compromise';
import fs from 'fs/promises';
import path from 'path';

export interface OCRResult {
  text: string;
  confidence: number;
  processingTime: number;
}

export interface NERResult {
  villages: string[];
  persons: string[];
  coordinates: { lat: number; lng: number }[];
  areas: number[];
  dates: string[];
  statuses: string[];
  confidence: number;
}

export interface DocumentProcessingResult {
  ocrResult: OCRResult;
  nerResult: NERResult;
  documentType: string;
  processingStatus: 'success' | 'error';
  errors?: string[];
}

export class DocumentProcessor {
  private static instance: DocumentProcessor;
  private tokenizer: natural.WordTokenizer;

  private constructor() {
    this.tokenizer = new natural.WordTokenizer();
  }

  public static getInstance(): DocumentProcessor {
    if (!DocumentProcessor.instance) {
      DocumentProcessor.instance = new DocumentProcessor();
    }
    return DocumentProcessor.instance;
  }

  async processDocument(filePath: string, fileType: string): Promise<DocumentProcessingResult> {
    const startTime = Date.now();
    
    try {
      // Step 1: Extract text using OCR or PDF parsing
      const ocrResult = await this.extractText(filePath, fileType);
      
      // Step 2: Apply NER to extracted text
      const nerResult = await this.performNER(ocrResult.text);
      
      // Step 3: Determine document type
      const documentType = this.classifyDocument(ocrResult.text);
      
      return {
        ocrResult,
        nerResult,
        documentType,
        processingStatus: 'success'
      };
    } catch (error) {
      return {
        ocrResult: { text: '', confidence: 0, processingTime: 0 },
        nerResult: { villages: [], persons: [], coordinates: [], areas: [], dates: [], statuses: [], confidence: 0 },
        documentType: 'unknown',
        processingStatus: 'error',
        errors: [error instanceof Error ? error.message : 'Unknown error']
      };
    }
  }

  private async extractText(filePath: string, fileType: string): Promise<OCRResult> {
    const startTime = Date.now();
    
    if (fileType === 'application/pdf') {
      return this.extractFromPDF(filePath, startTime);
    } else if (fileType.startsWith('image/')) {
      return this.extractFromImage(filePath, startTime);
    } else {
      throw new Error('Unsupported file type for OCR processing');
    }
  }

  private async extractFromPDF(filePath: string, startTime: number): Promise<OCRResult> {
    try {
      // Temporarily mock PDF processing until pdf-parse ESM issues are resolved
      const dataBuffer = await fs.readFile(filePath);
      
      // Mock PDF text extraction for demo purposes
      const mockText = `
        Forest Rights Application Document
        Village: Sample Village
        District: Sample District
        State: Madhya Pradesh
        Applicant: Sample Applicant Name
        Application Type: Individual Forest Rights (IFR)
        Land Area: 2.5 hectares
        Survey Number: 123/4
        Date: ${new Date().toLocaleDateString()}
        Status: Under Review
      `;
      
      return {
        text: mockText,
        confidence: 0.95,
        processingTime: Date.now() - startTime
      };
    } catch (error) {
      throw new Error(`PDF processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async extractFromImage(filePath: string, startTime: number): Promise<OCRResult> {
    try {
      const worker = await createWorker();
      await worker.loadLanguage('eng+hin'); // English + Hindi for Indian documents
      await worker.initialize('eng+hin');
      
      const { data: { text, confidence } } = await worker.recognize(filePath);
      await worker.terminate();
      
      return {
        text,
        confidence: confidence / 100,
        processingTime: Date.now() - startTime
      };
    } catch (error) {
      throw new Error(`OCR processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async performNER(text: string): Promise<NERResult> {
    const doc = nlp(text);
    const result: NERResult = {
      villages: [],
      persons: [],
      coordinates: [],
      areas: [],
      dates: [],
      statuses: [],
      confidence: 0.8
    };

    // Extract persons (names)
    const people = doc.people().out('array');
    result.persons = people.filter(person => person.length > 2);

    // Extract places (potential villages)
    const places = doc.places().out('array');
    result.villages = places.filter(place => 
      place.length > 2 && 
      !this.isCommonPlace(place)
    );

    // Extract dates
    const dates = doc.dates().out('array');
    result.dates = dates;

    // Extract coordinates using regex
    const coordRegex = /(\d{1,2}\.?\d*)[°\s]*([NS])\s*,?\s*(\d{1,3}\.?\d*)[°\s]*([EW])/gi;
    let coordMatch;
    while ((coordMatch = coordRegex.exec(text)) !== null) {
      const lat = parseFloat(coordMatch[1]) * (coordMatch[2] === 'S' ? -1 : 1);
      const lng = parseFloat(coordMatch[3]) * (coordMatch[4] === 'W' ? -1 : 1);
      if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        result.coordinates.push({ lat, lng });
      }
    }

    // Extract areas (hectares, acres)
    const areaRegex = /(\d+\.?\d*)\s*(hectares?|acres?|ha|ac)/gi;
    let areaMatch;
    while ((areaMatch = areaRegex.exec(text)) !== null) {
      let area = parseFloat(areaMatch[1]);
      // Convert acres to hectares for consistency
      if (areaMatch[2].toLowerCase().includes('acre') || areaMatch[2].toLowerCase().includes('ac')) {
        area = area * 0.404686; // acres to hectares
      }
      result.areas.push(area);
    }

    // Extract status keywords
    const statusKeywords = ['approved', 'rejected', 'pending', 'granted', 'verified', 'under review'];
    const lowerText = text.toLowerCase();
    result.statuses = statusKeywords.filter(status => lowerText.includes(status));

    // Extract village-specific patterns for Indian context
    const villagePatterns = [
      /village\s+([A-Za-z\s]+)/gi,
      /gram\s+([A-Za-z\s]+)/gi,
      /panchayat\s+([A-Za-z\s]+)/gi
    ];

    villagePatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const villageName = match[1].trim();
        if (villageName.length > 2 && !result.villages.includes(villageName)) {
          result.villages.push(villageName);
        }
      }
    });

    return result;
  }

  private classifyDocument(text: string): string {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('individual forest rights') || lowerText.includes('ifr')) {
      return 'IFR_APPLICATION';
    } else if (lowerText.includes('community rights') || lowerText.includes('community forest')) {
      return 'CFR_APPLICATION';
    } else if (lowerText.includes('patta') || lowerText.includes('title deed')) {
      return 'PATTA_DOCUMENT';
    } else if (lowerText.includes('survey') || lowerText.includes('boundary')) {
      return 'SURVEY_REPORT';
    } else if (lowerText.includes('satellite') || lowerText.includes('remote sensing')) {
      return 'SATELLITE_REPORT';
    }
    
    return 'GENERAL_DOCUMENT';
  }

  private isCommonPlace(place: string): boolean {
    const commonPlaces = ['india', 'state', 'district', 'block', 'tehsil', 'division'];
    return commonPlaces.includes(place.toLowerCase());
  }

  // Batch processing for multiple documents
  async processDocumentBatch(documents: { filePath: string; fileType: string; id: string }[]): Promise<Map<string, DocumentProcessingResult>> {
    const results = new Map<string, DocumentProcessingResult>();
    
    // Process documents in parallel with concurrency limit
    const concurrencyLimit = 3;
    const chunks = [];
    
    for (let i = 0; i < documents.length; i += concurrencyLimit) {
      chunks.push(documents.slice(i, i + concurrencyLimit));
    }
    
    for (const chunk of chunks) {
      const promises = chunk.map(async doc => {
        const result = await this.processDocument(doc.filePath, doc.fileType);
        return { id: doc.id, result };
      });
      
      const chunkResults = await Promise.all(promises);
      chunkResults.forEach(({ id, result }) => {
        results.set(id, result);
      });
    }
    
    return results;
  }
}

export const documentProcessor = DocumentProcessor.getInstance();