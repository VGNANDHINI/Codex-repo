import { Village, WeatherData, SatelliteImage, IotSensor } from "../../shared/schema.js";

export interface PredictionResult {
  prediction: number;
  confidence: number;
  factors: Record<string, number>;
  timeframe: string;
  explanation: string;
}

export interface ModelFeatures {
  // Environmental factors
  forestCoverPercent?: number;
  waterAvailability?: number;
  soilQuality?: number;
  rainfall?: number;
  temperature?: number;
  
  // Socio-economic factors
  population?: number;
  pattasGranted?: number;
  schemeEnrollment?: number;
  
  // Historical data
  historicalDeforestation?: number;
  cropYield?: number;
  waterStress?: number;
  
  // Satellite-derived indices
  ndvi?: number;
  evi?: number;
  moistureIndex?: number;
  
  // IoT sensor data
  soilMoisture?: number;
  airQuality?: number;
  waterQuality?: number;
}

export class PredictiveAnalytics {
  private models: Map<string, any> = new Map();
  private isInitialized = false;

  async initialize() {
    if (this.isInitialized) return;
    
    // Initialize pre-trained models or load existing ones
    await this.loadModels();
    this.isInitialized = true;
  }

  private async loadModels() {
    // In production, these would be actual trained models
    // For now, we'll create mock models with realistic logic
    
    this.models.set('deforestation', {
      type: 'regression',
      features: ['forestCoverPercent', 'population', 'rainfall', 'temperature', 'historicalDeforestation'],
      weights: [0.4, 0.3, -0.2, 0.1, 0.5]
    });

    this.models.set('water_scarcity', {
      type: 'classification',
      features: ['rainfall', 'waterAvailability', 'temperature', 'population', 'waterStress'],
      weights: [-0.5, -0.4, 0.3, 0.2, 0.4]
    });

    this.models.set('crop_failure', {
      type: 'regression',
      features: ['rainfall', 'soilQuality', 'temperature', 'ndvi', 'soilMoisture'],
      weights: [-0.3, -0.4, 0.2, -0.5, -0.3]
    });

    this.models.set('scheme_optimization', {
      type: 'optimization',
      features: ['population', 'pattasGranted', 'schemeEnrollment', 'waterAvailability', 'forestCoverPercent'],
      weights: [0.2, -0.3, 0.4, 0.2, 0.1]
    });
  }

  async predictDeforestation(
    villageData: Village, 
    weatherData: WeatherData[], 
    satelliteData: SatelliteImage[],
    timeframe: '6_months' | '1_year' | '5_years' = '1_year'
  ): Promise<PredictionResult> {
    await this.initialize();
    
    const features = await this.extractFeatures(villageData, weatherData, satelliteData);
    const model = this.models.get('deforestation');
    
    // Calculate weighted prediction
    let prediction = 0;
    const factors: Record<string, number> = {};
    
    model.features.forEach((feature: string, index: number) => {
      const value = features[feature as keyof ModelFeatures] || 0;
      const weight = model.weights[index];
      const contribution = value * weight;
      prediction += contribution;
      factors[feature] = contribution;
    });

    // Apply timeframe multiplier
    const timeMultiplier = {
      '6_months': 0.5,
      '1_year': 1.0,
      '5_years': 3.5
    }[timeframe];
    
    prediction *= timeMultiplier;
    
    // Normalize to 0-100 scale
    prediction = Math.max(0, Math.min(100, prediction * 10 + 50));
    
    const confidence = this.calculateConfidence(features, model);
    const explanation = this.generateExplanation('deforestation', prediction, factors, timeframe);

    return {
      prediction,
      confidence,
      factors,
      timeframe,
      explanation
    };
  }

  async predictWaterScarcity(
    villageData: Village,
    weatherData: WeatherData[],
    iotData: IotSensor[],
    timeframe: '6_months' | '1_year' | '5_years' = '1_year'
  ): Promise<PredictionResult> {
    await this.initialize();
    
    const features = await this.extractFeaturesForWater(villageData, weatherData, iotData);
    const model = this.models.get('water_scarcity');
    
    let riskScore = 0;
    const factors: Record<string, number> = {};
    
    // Calculate risk based on multiple factors
    const avgRainfall = weatherData.reduce((sum, w) => sum + (w.rainfall || 0), 0) / weatherData.length;
    const avgTemperature = weatherData.reduce((sum, w) => sum + (w.temperature || 0), 0) / weatherData.length;
    
    // Risk factors
    factors.rainfall_deficit = avgRainfall < 600 ? (600 - avgRainfall) / 600 * 40 : 0;
    factors.high_temperature = avgTemperature > 35 ? (avgTemperature - 35) * 5 : 0;
    factors.population_pressure = (villageData.population / 1000) * 5;
    factors.water_infrastructure = (villageData.waterIndex || 0) < 50 ? (50 - (villageData.waterIndex || 0)) : 0;
    
    riskScore = Object.values(factors).reduce((sum, val) => sum + val, 0);
    riskScore = Math.max(0, Math.min(100, riskScore));
    
    const confidence = this.calculateConfidence(features, model);
    const explanation = this.generateExplanation('water_scarcity', riskScore, factors, timeframe);

    return {
      prediction: riskScore,
      confidence,
      factors,
      timeframe,
      explanation
    };
  }

  async predictCropFailure(
    villageData: Village,
    weatherData: WeatherData[],
    satelliteData: SatelliteImage[],
    timeframe: '6_months' | '1_year' = '6_months'
  ): Promise<PredictionResult> {
    await this.initialize();
    
    const features = await this.extractFeatures(villageData, weatherData, satelliteData);
    const model = this.models.get('crop_failure');
    
    let failureRisk = 0;
    const factors: Record<string, number> = {};
    
    // Environmental stress factors
    const recentWeather = weatherData.slice(-30); // Last 30 days
    const avgRainfall = recentWeather.reduce((sum, w) => sum + (w.rainfall || 0), 0) / recentWeather.length;
    const avgTemp = recentWeather.reduce((sum, w) => sum + (w.temperature || 0), 0) / recentWeather.length;
    
    factors.drought_stress = avgRainfall < 50 ? (50 - avgRainfall) / 50 * 30 : 0;
    factors.heat_stress = avgTemp > 40 ? (avgTemp - 40) * 5 : 0;
    factors.soil_degradation = (villageData.soilQualityIndex || 0) < 60 ? (60 - (villageData.soilQualityIndex || 0)) / 2 : 0;
    factors.vegetation_health = (villageData.forestHealthIndex || 0) < 50 ? (50 - (villageData.forestHealthIndex || 0)) / 2 : 0;
    
    failureRisk = Object.values(factors).reduce((sum, val) => sum + val, 0);
    failureRisk = Math.max(0, Math.min(100, failureRisk));
    
    const confidence = this.calculateConfidence(features, model);
    const explanation = this.generateExplanation('crop_failure', failureRisk, factors, timeframe);

    return {
      prediction: failureRisk,
      confidence,
      factors,
      timeframe,
      explanation
    };
  }

  async optimizeSchemeAllocation(
    villages: Village[],
    availableSchemes: any[],
    budget: number
  ): Promise<{
    allocations: Array<{
      villageId: string;
      schemeId: string;
      priority: number;
      expectedImpact: number;
      cost: number;
    }>;
    totalImpact: number;
    budgetUtilization: number;
  }> {
    await this.initialize();
    
    const allocations: any[] = [];
    let totalCost = 0;
    let totalImpact = 0;
    
    // Calculate priority scores for each village-scheme combination
    const priorityMatrix: Array<{
      villageId: string;
      schemeId: string;
      priority: number;
      impact: number;
      cost: number;
    }> = [];
    
    for (const village of villages) {
      for (const scheme of availableSchemes) {
        const priority = this.calculateSchemePriority(village, scheme);
        const impact = this.calculateExpectedImpact(village, scheme);
        const cost = scheme.benefitAmount || 0;
        
        priorityMatrix.push({
          villageId: village.id,
          schemeId: scheme.id,
          priority,
          impact,
          cost
        });
      }
    }
    
    // Sort by priority/cost ratio
    priorityMatrix.sort((a, b) => (b.priority * b.impact / b.cost) - (a.priority * a.impact / a.cost));
    
    // Greedy allocation within budget
    for (const allocation of priorityMatrix) {
      if (totalCost + allocation.cost <= budget) {
        allocations.push({
          villageId: allocation.villageId,
          schemeId: allocation.schemeId,
          priority: allocation.priority,
          expectedImpact: allocation.impact,
          cost: allocation.cost
        });
        totalCost += allocation.cost;
        totalImpact += allocation.impact;
      }
    }
    
    return {
      allocations,
      totalImpact,
      budgetUtilization: (totalCost / budget) * 100
    };
  }

  private calculateSchemePriority(village: Village, scheme: any): number {
    let priority = 50; // Base priority
    
    // Water-related schemes
    if (scheme.name.toLowerCase().includes('water') || scheme.name.toLowerCase().includes('irrigation')) {
      priority += (100 - (village.waterIndex || 0)) * 0.5;
    }
    
    // Forest-related schemes
    if (scheme.name.toLowerCase().includes('forest') || scheme.name.toLowerCase().includes('conservation')) {
      priority += (100 - (village.forestHealthIndex || 0)) * 0.5;
    }
    
    // Agriculture schemes
    if (scheme.name.toLowerCase().includes('agriculture') || scheme.name.toLowerCase().includes('crop')) {
      priority += (100 - (village.soilQualityIndex || 0)) * 0.5;
    }
    
    // Population-based adjustment
    priority += Math.log10(village.population || 1) * 5;
    
    return Math.max(0, Math.min(100, priority));
  }

  private calculateExpectedImpact(village: Village, scheme: any): number {
    // Base impact calculation
    let impact = 30;
    
    // Scheme-specific impact multipliers
    const impactMultipliers: Record<string, number> = {
      'PM-KISAN': 1.2,
      'MGNREGA': 1.5,
      'PMAY': 1.3,
      'Jal Jeevan Mission': 1.8,
      'Forest Conservation': 1.6
    };
    
    impact *= impactMultipliers[scheme.name] || 1.0;
    
    // Village readiness factor
    const readiness = ((village.waterIndex || 0) + (village.forestHealthIndex || 0) + (village.soilQualityIndex || 0)) / 3;
    impact *= (readiness / 100) * 0.5 + 0.75; // 0.75 to 1.25 multiplier
    
    return Math.max(0, Math.min(100, impact));
  }

  private async extractFeatures(
    village: Village,
    weatherData: WeatherData[],
    satelliteData: SatelliteImage[]
  ): Promise<ModelFeatures> {
    const recentWeather = weatherData.slice(-30);
    const recentSatellite = satelliteData.slice(-5);
    
    return {
      forestCoverPercent: village.assets?.forestCover || 0,
      waterAvailability: village.waterIndex || 0,
      soilQuality: village.soilQualityIndex || 0,
      rainfall: recentWeather.reduce((sum, w) => sum + (w.rainfall || 0), 0) / recentWeather.length,
      temperature: recentWeather.reduce((sum, w) => sum + (w.temperature || 0), 0) / recentWeather.length,
      population: village.population,
      pattasGranted: village.pattasGranted,
      ndvi: this.calculateNDVI(recentSatellite),
      moistureIndex: this.calculateMoistureIndex(recentSatellite)
    };
  }

  private async extractFeaturesForWater(
    village: Village,
    weatherData: WeatherData[],
    iotData: IotSensor[]
  ): Promise<ModelFeatures> {
    const recentWeather = weatherData.slice(-30);
    const recentIoT = iotData.filter(d => d.sensorType === 'water_quality').slice(-10);
    
    return {
      waterAvailability: village.waterIndex || 0,
      rainfall: recentWeather.reduce((sum, w) => sum + (w.rainfall || 0), 0) / recentWeather.length,
      temperature: recentWeather.reduce((sum, w) => sum + (w.temperature || 0), 0) / recentWeather.length,
      population: village.population,
      waterQuality: recentIoT.reduce((sum, iot) => sum + (iot.readings?.waterQuality || 0), 0) / recentIoT.length
    };
  }

  private calculateNDVI(satelliteData: SatelliteImage[]): number {
    // Mock NDVI calculation - in production, this would process actual satellite imagery
    const avgForestCover = satelliteData.reduce((sum, sat) => 
      sum + (sat.processedData?.forestCover || 0), 0) / satelliteData.length;
    return avgForestCover / 100; // Normalize to 0-1
  }

  private calculateMoistureIndex(satelliteData: SatelliteImage[]): number {
    // Mock moisture index calculation
    const avgWaterBodies = satelliteData.reduce((sum, sat) => 
      sum + (sat.processedData?.waterBodies || 0), 0) / satelliteData.length;
    return avgWaterBodies / 100; // Normalize to 0-1
  }

  private calculateConfidence(features: ModelFeatures, model: any): number {
    // Calculate confidence based on data completeness and model reliability
    const featureCompleteness = Object.values(features).filter(v => v !== undefined && v !== null).length / model.features.length;
    const baseConfidence = 70; // Base model confidence
    return Math.max(30, Math.min(95, baseConfidence * featureCompleteness));
  }

  private generateExplanation(
    predictionType: string,
    prediction: number,
    factors: Record<string, number>,
    timeframe: string
  ): string {
    const topFactors = Object.entries(factors)
      .sort(([,a], [,b]) => Math.abs(b) - Math.abs(a))
      .slice(0, 3);
    
    const factorStrings = topFactors.map(([factor, value]) => {
      const impact = Math.abs(value) > 10 ? 'high' : Math.abs(value) > 5 ? 'medium' : 'low';
      return `${factor.replace(/_/g, ' ')} (${impact} impact)`;
    });
    
    const risk = prediction > 70 ? 'high' : prediction > 40 ? 'medium' : 'low';
    
    return `Based on ${timeframe} analysis, the ${risk} risk (${prediction.toFixed(1)}%) is primarily driven by: ${factorStrings.join(', ')}.`;
  }

  // Batch prediction for multiple villages
  async batchPredict(
    villages: Village[],
    predictionType: 'deforestation' | 'water_scarcity' | 'crop_failure',
    weatherData: WeatherData[],
    satelliteData: SatelliteImage[],
    iotData: IotSensor[] = []
  ): Promise<Array<{ villageId: string; prediction: PredictionResult }>> {
    const results: Array<{ villageId: string; prediction: PredictionResult }> = [];
    
    for (const village of villages) {
      const villageWeather = weatherData.filter(w => w.villageId === village.id);
      const villageSatellite = satelliteData.filter(s => s.villageId === village.id);
      const villageIoT = iotData.filter(i => i.villageId === village.id);
      
      let prediction: PredictionResult;
      
      switch (predictionType) {
        case 'deforestation':
          prediction = await this.predictDeforestation(village, villageWeather, villageSatellite);
          break;
        case 'water_scarcity':
          prediction = await this.predictWaterScarcity(village, villageWeather, villageIoT);
          break;
        case 'crop_failure':
          prediction = await this.predictCropFailure(village, villageWeather, villageSatellite);
          break;
        default:
          throw new Error(`Unknown prediction type: ${predictionType}`);
      }
      
      results.push({ villageId: village.id, prediction });
    }
    
    return results;
  }
}

export const predictiveAnalytics = new PredictiveAnalytics();