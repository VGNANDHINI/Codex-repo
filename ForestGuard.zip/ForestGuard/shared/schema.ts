import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const fraVillages = pgTable("fra_villages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  state: text("state").notNull(),
  district: text("district").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  totalClaims: integer("total_claims").default(0).notNull(),
  pattasGranted: integer("pattas_granted").default(0).notNull(),
  forestArea: real("forest_area").default(0).notNull(),
  population: integer("population").default(0).notNull(),
  assets: jsonb("assets").$type<{
    agriculturalLand?: number;
    waterBodies?: number;
    forestCover?: number;
    homesteads?: number;
    roads?: number;
    infrastructure?: number;
    aiMappedArea?: number;
    lastSatelliteUpdate?: string;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  // AI & IoT fields
  waterIndex: real("water_index").default(0),
  forestHealthIndex: real("forest_health_index").default(0),
  soilQualityIndex: real("soil_quality_index").default(0),
  lastAiAnalysis: timestamp("last_ai_analysis"),
  satelliteImageUrl: text("satellite_image_url"),
});

export const fraClaims = pgTable("fra_claims", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  applicationId: text("application_id").notNull().unique(),
  villageId: varchar("village_id").references(() => fraVillages.id),
  claimantName: text("claimant_name").notNull(),
  claimType: text("claim_type").notNull(), // IFR, CR, CFR
  status: text("status").notNull(), // pending, approved, rejected
  area: real("area").default(0).notNull(),
  submissionDate: timestamp("submission_date").defaultNow(),
  approvalDate: timestamp("approval_date"),
  rejectionReason: text("rejection_reason"),
  // AI/NER extracted fields
  aiExtractedData: jsonb("ai_extracted_data").$type<{
    coordinates?: { lat: number; lng: number };
    landUseType?: string;
    forestCoverPercent?: number;
    nearestWaterBody?: number;
    predictedEligibility?: number;
  }>(),
  processingStatus: text("processing_status").default("pending"),
});

export const fraDocuments = pgTable("fra_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").default(0).notNull(),
  category: text("category").notNull(), // application, patta, survey, satellite
  villageId: varchar("village_id").references(() => fraVillages.id),
  claimId: varchar("claim_id").references(() => fraClaims.id),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  processed: boolean("processed").default(false).notNull(),
  filePath: text("file_path"),
  // AI processing fields
  ocrText: text("ocr_text"),
  nerEntities: jsonb("ner_entities").$type<{
    villages?: string[];
    persons?: string[];
    coordinates?: { lat: number; lng: number }[];
    areas?: number[];
    dates?: string[];
    statuses?: string[];
  }>(),
  aiConfidence: real("ai_confidence").default(0),
  processingErrors: text("processing_errors"),
});

export const cssSchemes = pgTable("css_schemes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  eligibilityCriteria: jsonb("eligibility_criteria"),
  benefitAmount: real("benefit_amount"),
  isActive: boolean("is_active").default(true),
});

export const schemeEnrollments = pgTable("scheme_enrollments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  schemeId: varchar("scheme_id").references(() => cssSchemes.id),
  eligible: integer("eligible").default(0).notNull(),
  enrolled: integer("enrolled").default(0).notNull(),
  coverage: real("coverage").default(0).notNull(),
  lastUpdated: timestamp("last_updated").defaultNow(),
  aiRecommendedPriority: text("ai_recommended_priority").default("medium"),
  predictedImpact: real("predicted_impact").default(0),
});

export const dssRecommendations = pgTable("dss_recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  priority: text("priority").notNull(), // high, medium, low
  category: text("category").notNull(), // water, agriculture, infrastructure
  status: text("status").default("pending"), // pending, approved, implemented, rejected
  estimatedCost: real("estimated_cost"),
  beneficiaries: integer("beneficiaries"),
  createdAt: timestamp("created_at").defaultNow(),
  aiGenerated: boolean("ai_generated").default(true),
  confidenceScore: real("confidence_score").default(0),
  implementationTimeline: text("implementation_timeline"),
  expectedImpact: jsonb("expected_impact").$type<{
    waterIndexImprovement?: number;
    forestHealthImprovement?: number;
    agricultureProductivityGain?: number;
    livelihoodImpact?: number;
  }>(),
});

// IoT Sensor Data Table
export const iotSensorData = pgTable("iot_sensor_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  sensorType: text("sensor_type").notNull(), // soil_moisture, water_quality, air_quality, forest_health
  sensorId: text("sensor_id").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  readings: jsonb("readings").$type<{
    soilMoisture?: number;
    pH?: number;
    temperature?: number;
    humidity?: number;
    waterQuality?: number;
    airQuality?: number;
    co2Level?: number;
  }>(),
  timestamp: timestamp("timestamp").defaultNow(),
  batteryLevel: real("battery_level"),
  status: text("status").default("active"), // active, inactive, maintenance
});

// AI Model Training Data
export const aiModelData = pgTable("ai_model_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  modelType: text("model_type").notNull(), // land_classification, water_detection, forest_health, ocr, ner
  version: text("version").notNull(),
  trainingData: jsonb("training_data"),
  accuracy: real("accuracy"),
  lastTrained: timestamp("last_trained").defaultNow(),
  isActive: boolean("is_active").default(false),
  parameters: jsonb("parameters"),
  performanceMetrics: jsonb("performance_metrics").$type<{
    precision?: number;
    recall?: number;
    f1Score?: number;
    rocAuc?: number;
  }>(),
});

// Satellite Imagery Data
export const satelliteImagery = pgTable("satellite_imagery", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  imageUrl: text("image_url").notNull(),
  imageType: text("image_type").notNull(), // rgb, ndvi, evi, thermal
  captureDate: timestamp("capture_date").notNull(),
  resolution: real("resolution"),
  cloudCover: real("cloud_cover"),
  bounds: jsonb("bounds").$type<{
    northeast: { lat: number; lng: number };
    southwest: { lat: number; lng: number };
  }>(),
  processedData: jsonb("processed_data").$type<{
    forestCover?: number;
    agriculturalArea?: number;
    waterBodies?: number;
    builtUpArea?: number;
    bareGround?: number;
  }>(),
  processingStatus: text("processing_status").default("pending"),
});

// User Roles and Authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  role: text("role").notNull(), // admin, ministry_official, district_officer, forest_officer, ngo, field_staff
  department: text("department"),
  state: text("state"),
  district: text("district"),
  permissions: jsonb("permissions").$type<{
    canViewAllStates?: boolean;
    canEditData?: boolean;
    canApproveRecommendations?: boolean;
    canAccessAnalytics?: boolean;
    canManageUsers?: boolean;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  lastLogin: timestamp("last_login"),
  isActive: boolean("is_active").default(true),
});

// Mobile Field Data Collection
export const fieldDataCollection = pgTable("field_data_collection", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  villageId: varchar("village_id").references(() => fraVillages.id),
  dataType: text("data_type").notNull(), // claim_verification, asset_survey, beneficiary_feedback
  collectedData: jsonb("collected_data"),
  geoLocation: jsonb("geo_location").$type<{
    latitude: number;
    longitude: number;
    accuracy: number;
  }>(),
  images: jsonb("images").$type<string[]>(),
  notes: text("notes"),
  collectionDate: timestamp("collection_date").defaultNow(),
  verificationStatus: text("verification_status").default("pending"),
});

// Blockchain Patta Verification
export const blockchainPattas = pgTable("blockchain_pattas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  claimId: varchar("claim_id").references(() => fraClaims.id),
  blockchainHash: text("blockchain_hash").notNull().unique(),
  transactionId: text("transaction_id").notNull(),
  smartContractAddress: text("smart_contract_address"),
  verificationStatus: text("verification_status").default("pending"),
  digitalSignature: text("digital_signature"),
  merkleRoot: text("merkle_root"),
  timestampCreated: timestamp("timestamp_created").defaultNow(),
  lastVerified: timestamp("last_verified"),
  isValid: boolean("is_valid").default(true),
  auditTrail: jsonb("audit_trail").$type<{
    changes?: Array<{
      timestamp: string;
      field: string;
      oldValue: string;
      newValue: string;
      authorizedBy: string;
    }>;
  }>(),
});

// Drone and UAV Data
export const droneData = pgTable("drone_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  droneId: text("drone_id").notNull(),
  flightPath: jsonb("flight_path").$type<{
    coordinates: Array<[number, number, number]>;
    altitude: number;
    speed: number;
  }>(),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  captureTimestamp: timestamp("capture_timestamp").defaultNow(),
  batteryLevel: real("battery_level"),
  weatherConditions: jsonb("weather_conditions").$type<{
    temperature: number;
    humidity: number;
    windSpeed: number;
    visibility: number;
  }>(),
  aiDetectedObjects: jsonb("ai_detected_objects").$type<Array<{
    objectType: string;
    coordinates: [number, number];
    confidence: number;
    boundingBox: [number, number, number, number];
  }>>(),
  anomaliesDetected: jsonb("anomalies_detected").$type<Array<{
    type: string;
    severity: string;
    location: [number, number];
    confidence: number;
    description: string;
  }>>(),
  flightStatus: text("flight_status").default("completed"),
  processedBy: text("processed_by"),
});

// Multi-Language Support
export const languageTranslations = pgTable("language_translations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  textKey: text("text_key").notNull(),
  language: text("language").notNull(), // hi, bn, ta, te, mr, gu, kn, ml, or, as, pa, ur
  translation: text("translation").notNull(),
  category: text("category").notNull(), // ui, status, documents, reports
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Weather and Climate Data
export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  date: timestamp("date").notNull(),
  temperature: real("temperature"),
  humidity: real("humidity"),
  rainfall: real("rainfall"),
  windSpeed: real("wind_speed"),
  pressure: real("pressure"),
  visibility: real("visibility"),
  uvIndex: real("uv_index"),
  soilTemperature: real("soil_temperature"),
  evapotranspiration: real("evapotranspiration"),
  dataSource: text("data_source"), // IMD, satellite, IoT
  forecastData: jsonb("forecast_data").$type<{
    next7Days?: Array<{
      date: string;
      temperature: [number, number];
      rainfall: number;
      humidity: number;
    }>;
    seasonalPrediction?: {
      monsoonIntensity: number;
      droughtRisk: number;
      floodRisk: number;
    };
  }>(),
});

// Predictive Analytics Models
export const predictiveModels = pgTable("predictive_models", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  modelName: text("model_name").notNull(),
  modelType: text("model_type").notNull(), // deforestation, water_scarcity, crop_failure, scheme_optimization
  algorithm: text("algorithm").notNull(), // random_forest, neural_network, svm, ensemble
  features: jsonb("features").$type<string[]>(),
  trainingDataSize: integer("training_data_size"),
  accuracy: real("accuracy"),
  precision: real("precision"),
  recall: real("recall"),
  f1Score: real("f1_score"),
  trainingDate: timestamp("training_date").defaultNow(),
  isActive: boolean("is_active").default(false),
  hyperparameters: jsonb("hyperparameters"),
  featureImportance: jsonb("feature_importance"),
  crossValidationScore: real("cross_validation_score"),
});

// Anomaly Detection Results
export const anomalyDetection = pgTable("anomaly_detection", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  villageId: varchar("village_id").references(() => fraVillages.id),
  anomalyType: text("anomaly_type").notNull(), // illegal_logging, mining, encroachment, land_use_change
  severity: text("severity").notNull(), // low, medium, high, critical
  confidenceScore: real("confidence_score").notNull(),
  detectionMethod: text("detection_method").notNull(), // satellite, drone, IoT, citizen_report
  location: jsonb("location").$type<{
    latitude: number;
    longitude: number;
    area?: number;
    boundingBox?: [number, number, number, number];
  }>(),
  detectedAt: timestamp("detected_at").defaultNow(),
  evidenceUrls: jsonb("evidence_urls").$type<string[]>(),
  description: text("description"),
  verificationStatus: text("verification_status").default("pending"),
  actionTaken: text("action_taken"),
  resolvedAt: timestamp("resolved_at"),
  estimatedDamage: real("estimated_damage"),
  alertsSent: jsonb("alerts_sent").$type<Array<{
    recipient: string;
    method: string;
    sentAt: string;
  }>>(),
});

// Citizen Engagement
export const citizenReports = pgTable("citizen_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  citizenId: text("citizen_id"),
  villageId: varchar("village_id").references(() => fraVillages.id),
  reportType: text("report_type").notNull(), // environmental_issue, illegal_activity, claim_feedback, scheme_feedback
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: jsonb("location").$type<{
    latitude: number;
    longitude: number;
    accuracy: number;
  }>(),
  photos: jsonb("photos").$type<string[]>(),
  severity: text("severity").default("medium"),
  status: text("status").default("submitted"), // submitted, under_review, verified, resolved, rejected
  submittedAt: timestamp("submitted_at").defaultNow(),
  verifiedAt: timestamp("verified_at"),
  verifiedBy: varchar("verified_by").references(() => users.id),
  gamificationPoints: integer("gamification_points").default(0),
  publiclyVisible: boolean("publicly_visible").default(false),
});

// Scenario Simulation Results
export const scenarioSimulations = pgTable("scenario_simulations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  simulationName: text("simulation_name").notNull(),
  simulationType: text("simulation_type").notNull(), // resource_allocation, intervention_impact, climate_scenario
  inputParameters: jsonb("input_parameters"),
  targetVillages: jsonb("target_villages").$type<string[]>(),
  timeframe: text("timeframe"), // 6_months, 1_year, 5_years
  predictedOutcomes: jsonb("predicted_outcomes").$type<{
    forestHealthImprovement?: number;
    waterIndexImprovement?: number;
    livelihoodImpact?: number;
    economicBenefit?: number;
    environmentalImpact?: number;
  }>(),
  confidenceInterval: jsonb("confidence_interval").$type<{
    lower: number;
    upper: number;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
  simulationStatus: text("simulation_status").default("completed"),
});

// Insert schemas
export const insertVillageSchema = createInsertSchema(fraVillages).omit({
  id: true,
  createdAt: true,
});

export const insertClaimSchema = createInsertSchema(fraClaims).omit({
  id: true,
  submissionDate: true,
  approvalDate: true,
});

export const insertDocumentSchema = createInsertSchema(fraDocuments).omit({
  id: true,
  uploadedAt: true,
});

export const insertSchemeSchema = createInsertSchema(cssSchemes).omit({
  id: true,
});

export const insertEnrollmentSchema = createInsertSchema(schemeEnrollments).omit({
  id: true,
  lastUpdated: true,
});

export const insertRecommendationSchema = createInsertSchema(dssRecommendations).omit({
  id: true,
  createdAt: true,
});

export const insertIotSensorSchema = createInsertSchema(iotSensorData).omit({
  id: true,
  timestamp: true,
});

export const insertAiModelSchema = createInsertSchema(aiModelData).omit({
  id: true,
  lastTrained: true,
});

export const insertSatelliteImagerySchema = createInsertSchema(satelliteImagery).omit({
  id: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const insertFieldDataSchema = createInsertSchema(fieldDataCollection).omit({
  id: true,
  collectionDate: true,
});

export const insertBlockchainPattaSchema = createInsertSchema(blockchainPattas).omit({
  id: true,
  timestampCreated: true,
  lastVerified: true,
});

export const insertDroneDataSchema = createInsertSchema(droneData).omit({
  id: true,
  captureTimestamp: true,
});

export const insertLanguageTranslationSchema = createInsertSchema(languageTranslations).omit({
  id: true,
  lastUpdated: true,
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
});

export const insertPredictiveModelSchema = createInsertSchema(predictiveModels).omit({
  id: true,
  trainingDate: true,
});

export const insertAnomalyDetectionSchema = createInsertSchema(anomalyDetection).omit({
  id: true,
  detectedAt: true,
  resolvedAt: true,
});

export const insertCitizenReportSchema = createInsertSchema(citizenReports).omit({
  id: true,
  submittedAt: true,
  verifiedAt: true,
});

export const insertScenarioSimulationSchema = createInsertSchema(scenarioSimulations).omit({
  id: true,
  createdAt: true,
});

// Types
export type Village = typeof fraVillages.$inferSelect;
export type InsertVillage = z.infer<typeof insertVillageSchema>;
export type Claim = typeof fraClaims.$inferSelect;
export type InsertClaim = z.infer<typeof insertClaimSchema>;
export type Document = typeof fraDocuments.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Scheme = typeof cssSchemes.$inferSelect;
export type InsertScheme = z.infer<typeof insertSchemeSchema>;
export type Enrollment = typeof schemeEnrollments.$inferSelect;
export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type Recommendation = typeof dssRecommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
export type IotSensor = typeof iotSensorData.$inferSelect;
export type InsertIotSensor = z.infer<typeof insertIotSensorSchema>;
export type AiModel = typeof aiModelData.$inferSelect;
export type InsertAiModel = z.infer<typeof insertAiModelSchema>;
export type SatelliteImage = typeof satelliteImagery.$inferSelect;
export type InsertSatelliteImage = z.infer<typeof insertSatelliteImagerySchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type FieldData = typeof fieldDataCollection.$inferSelect;
export type InsertFieldData = z.infer<typeof insertFieldDataSchema>;
export type BlockchainPatta = typeof blockchainPattas.$inferSelect;
export type InsertBlockchainPatta = z.infer<typeof insertBlockchainPattaSchema>;
export type DroneData = typeof droneData.$inferSelect;
export type InsertDroneData = z.infer<typeof insertDroneDataSchema>;
export type LanguageTranslation = typeof languageTranslations.$inferSelect;
export type InsertLanguageTranslation = z.infer<typeof insertLanguageTranslationSchema>;
export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type PredictiveModel = typeof predictiveModels.$inferSelect;
export type InsertPredictiveModel = z.infer<typeof insertPredictiveModelSchema>;
export type AnomalyDetection = typeof anomalyDetection.$inferSelect;
export type InsertAnomalyDetection = z.infer<typeof insertAnomalyDetectionSchema>;
export type CitizenReport = typeof citizenReports.$inferSelect;
export type InsertCitizenReport = z.infer<typeof insertCitizenReportSchema>;
export type ScenarioSimulation = typeof scenarioSimulations.$inferSelect;
export type InsertScenarioSimulation = z.infer<typeof insertScenarioSimulationSchema>;
