import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Village, Scheme, Enrollment } from "@shared/schema";

interface StatsOverviewProps {
  villageId: string | null;
}

export default function StatsOverview({ villageId }: StatsOverviewProps) {
  const { data: village } = useQuery<Village>({
    queryKey: ["/api/villages", villageId],
    enabled: !!villageId,
  });

  const { data: schemes = [] } = useQuery<Scheme[]>({
    queryKey: ["/api/schemes"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
    queryFn: () => fetch("/api/enrollments?villageId=" + villageId).then(res => res.json()),
    enabled: !!villageId,
  });

  if (!village) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground">
            Select a village to view details
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Village Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Village Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Village Name</label>
            <p className="text-sm" data-testid="text-selected-village-name">{village.name}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">District</label>
            <p className="text-sm" data-testid="text-selected-village-location">
              {village.district}, {village.state}
            </p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Total Claims</label>
            <p className="text-sm" data-testid="text-selected-village-total-claims">{village.totalClaims}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Pattas Granted</label>
            <p className="text-sm" data-testid="text-selected-village-pattas-granted">{village.pattasGranted}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Forest Area</label>
            <p className="text-sm" data-testid="text-selected-village-forest-area">
              {village.forestArea} hectares
            </p>
          </div>
          <Button className="w-full mt-4" data-testid="button-view-detailed-report">
            View Detailed Report
          </Button>
        </CardContent>
      </Card>

      {/* Asset Summary */}
      {village.assets && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Asset Mapping</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Agricultural Land</span>
              <span className="text-sm font-medium" data-testid="text-asset-agricultural">
                {village.assets.agriculturalLand || 0} ha
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Water Bodies</span>
              <span className="text-sm font-medium" data-testid="text-asset-water">
                {village.assets.waterBodies || 0} ponds
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Forest Cover</span>
              <span className="text-sm font-medium" data-testid="text-asset-forest">
                {village.assets.forestCover || 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Homesteads</span>
              <span className="text-sm font-medium" data-testid="text-asset-homesteads">
                {village.assets.homesteads || 0}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* CSS Schemes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Available Schemes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {schemes.slice(0, 3).map((scheme) => {
            const enrollment = enrollments.find(e => e.schemeId === scheme.id);
            const status = enrollment 
              ? enrollment.coverage > 80 ? "Active" : "Pending"
              : "Eligible";
            const statusColor = status === "Active" ? "bg-secondary" : "bg-chart-4";
            
            return (
              <div key={scheme.id} className="flex items-center justify-between p-2 bg-secondary/10 rounded">
                <span className="text-sm font-medium">{scheme.name}</span>
                <span className={`text-xs text-white px-2 py-1 rounded ${statusColor}`}>
                  {status}
                </span>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
