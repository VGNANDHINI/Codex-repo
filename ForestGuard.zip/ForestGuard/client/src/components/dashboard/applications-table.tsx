import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { Claim, Village } from "@shared/schema";

export default function ApplicationsTable() {
  const { data: claims = [] } = useQuery<Claim[]>({
    queryKey: ["/api/claims"],
  });

  const { data: villages = [] } = useQuery<Village[]>({
    queryKey: ["/api/villages"],
  });

  const getVillageName = (villageId: string | null) => {
    if (!villageId) return "Unknown";
    const village = villages.find(v => v.id === villageId);
    return village ? village.name : "Unknown";
  };

  const getVillageState = (villageId: string | null) => {
    if (!villageId) return "Unknown";
    const village = villages.find(v => v.id === villageId);
    return village ? village.state : "Unknown";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge variant="secondary" className="bg-secondary/20 text-secondary">Approved</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-chart-4/20 text-chart-4">Pending</Badge>;
      case "rejected":
        return <Badge variant="destructive" className="bg-destructive/20 text-destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatClaimType = (type: string) => {
    switch (type) {
      case "IFR":
        return "Individual Forest Rights";
      case "CR":
        return "Community Rights";
      case "CFR":
        return "Community Forest Resource";
      default:
        return type;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent FRA Applications</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Application ID</TableHead>
              <TableHead>Village</TableHead>
              <TableHead>State</TableHead>
              <TableHead>Claim Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {claims.slice(0, 10).map((claim) => (
              <TableRow key={claim.id} data-testid={`row-application-${claim.id}`}>
                <TableCell className="font-medium" data-testid={`text-application-id-${claim.id}`}>
                  {claim.applicationId}
                </TableCell>
                <TableCell data-testid={`text-village-${claim.id}`}>
                  {getVillageName(claim.villageId)}
                </TableCell>
                <TableCell data-testid={`text-state-${claim.id}`}>
                  {getVillageState(claim.villageId)}
                </TableCell>
                <TableCell data-testid={`text-claim-type-${claim.id}`}>
                  {formatClaimType(claim.claimType)}
                </TableCell>
                <TableCell data-testid={`badge-status-${claim.id}`}>
                  {getStatusBadge(claim.status)}
                </TableCell>
                <TableCell data-testid={`text-date-${claim.id}`}>
                  {claim.submissionDate ? new Date(claim.submissionDate).toLocaleDateString() : "N/A"}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
