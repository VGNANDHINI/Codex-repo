import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import type { Village, Claim } from "@shared/schema";

export default function ChartsSection() {
  const { data: villages = [] } = useQuery<Village[]>({
    queryKey: ["/api/villages"],
  });

  const { data: claims = [] } = useQuery<Claim[]>({
    queryKey: ["/api/claims"],
  });

  // Prepare data for charts
  const stateData = villages.reduce((acc, village) => {
    const existing = acc.find(item => item.name === village.state);
    if (existing) {
      existing.value += village.totalClaims;
    } else {
      acc.push({ name: village.state, value: village.totalClaims });
    }
    return acc;
  }, [] as Array<{ name: string; value: number }>);

  const statusData = [
    { name: "Approved", value: claims.filter(c => c.status === "approved").length, color: "#10b981" },
    { name: "Pending", value: claims.filter(c => c.status === "pending").length, color: "#f59e0b" },
    { name: "Rejected", value: claims.filter(c => c.status === "rejected").length, color: "#ef4444" },
  ];

  // Mock monthly trends data
  const monthlyData = [
    { name: "Jan", value: 123 },
    { name: "Feb", value: 145 },
    { name: "Mar", value: 167 },
    { name: "Apr", value: 189 },
    { name: "May", value: 156 },
    { name: "Jun", value: 178 },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* State-wise Progress */}
      <Card>
        <CardHeader>
          <CardTitle>State-wise Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={stateData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip />
              <Bar dataKey="value" fill="hsl(var(--primary))" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Claims Status */}
      <Card>
        <CardHeader>
          <CardTitle>Claims Status</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Monthly Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2} 
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
