import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { Recommendation, Village, Scheme, Enrollment } from "@shared/schema";

export default function RecommendationsPanel() {
  const { data: recommendations = [] } = useQuery<Recommendation[]>({
    queryKey: ["/api/recommendations"],
  });

  const { data: villages = [] } = useQuery<Village[]>({
    queryKey: ["/api/villages"],
  });

  const { data: schemes = [] } = useQuery<Scheme[]>({
    queryKey: ["/api/schemes"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge className="bg-chart-1/20 text-chart-1">High Priority</Badge>;
      case "medium":
        return <Badge className="bg-chart-2/20 text-chart-2">Medium Priority</Badge>;
      case "low":
        return <Badge className="bg-chart-3/20 text-chart-3">Low Priority</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };

  // Mock recommendations for demonstration
  const mockRecommendations = [
    {
      id: "1",
      title: "Water Infrastructure Priority",
      description: "Chiraidongri village shows low water index. Recommend borewell installation under Jal Shakti Mission for 156 households.",
      priority: "high",
      category: "water",
      status: "pending"
    },
    {
      id: "2",
      title: "Agricultural Support",
      description: "31 patta holders in Chiraidongri eligible for PM-KISAN benefits. Auto-enrollment recommended.",
      priority: "medium",
      category: "agriculture",
      status: "pending"
    }
  ];

  // Calculate scheme eligibility matrix
  const schemeMatrix = schemes.map(scheme => {
    const schemeEnrollments = enrollments.filter(e => e.schemeId === scheme.id);
    const totalEligible = schemeEnrollments.reduce((sum, e) => sum + e.eligible, 0);
    const totalEnrolled = schemeEnrollments.reduce((sum, e) => sum + e.enrolled, 0);
    const coverage = totalEligible > 0 ? Math.round((totalEnrolled / totalEligible) * 100) : 0;

    return {
      scheme: scheme.name,
      eligible: totalEligible,
      enrolled: totalEnrolled,
      coverage
    };
  });

  // Mock priority villages
  const priorityVillages = [
    {
      name: "Chiraidongri",
      state: "Madhya Pradesh",
      district: "Betul",
      priority: "high",
      waterCoverage: 34,
      schemeEnrollment: 67,
      pendingClaims: 16
    },
    {
      name: "Kanchanpur",
      state: "Tripura", 
      district: "North Tripura",
      priority: "medium",
      waterCoverage: 78,
      schemeEnrollment: 45,
      pendingClaims: 8
    },
    {
      name: "Rayagada",
      state: "Odisha",
      district: "Rayagada", 
      priority: "high",
      waterCoverage: 23,
      schemeEnrollment: 52,
      pendingClaims: 24
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* DSS Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>AI Recommendations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {mockRecommendations.map((rec) => (
              <div key={rec.id} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium text-card-foreground">{rec.title}</h4>
                  {getPriorityBadge(rec.priority)}
                </div>
                <p className="text-sm text-muted-foreground mb-3">{rec.description}</p>
                <div className="flex space-x-2">
                  <Button size="sm" data-testid={`button-implement-${rec.id}`}>
                    Implement
                  </Button>
                  <Button variant="outline" size="sm" data-testid={`button-review-${rec.id}`}>
                    Review
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Scheme Eligibility Matrix */}
        <Card>
          <CardHeader>
            <CardTitle>Scheme Eligibility Matrix</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Scheme</TableHead>
                  <TableHead className="text-center">Eligible</TableHead>
                  <TableHead className="text-center">Enrolled</TableHead>
                  <TableHead className="text-center">Coverage</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {schemeMatrix.map((item) => (
                  <TableRow key={item.scheme}>
                    <TableCell className="font-medium">{item.scheme}</TableCell>
                    <TableCell className="text-center">{item.eligible}</TableCell>
                    <TableCell className="text-center">{item.enrolled}</TableCell>
                    <TableCell className="text-center">
                      <Badge 
                        className={
                          item.coverage >= 80 
                            ? "bg-secondary/20 text-secondary" 
                            : "bg-chart-4/20 text-chart-4"
                        }
                      >
                        {item.coverage}%
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Priority Villages */}
      <Card>
        <CardHeader>
          <CardTitle>Priority Villages for Intervention</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {priorityVillages.map((village) => (
              <div 
                key={village.name}
                className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow"
                data-testid={`card-priority-village-${village.name.toLowerCase()}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-card-foreground">{village.name}</h4>
                  {getPriorityBadge(village.priority)}
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  {village.district}, {village.state}
                </p>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span>Water Coverage:</span>
                    <span className={village.waterCoverage < 50 ? "text-chart-1" : "text-chart-2"}>
                      {village.waterCoverage}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Scheme Enrollment:</span>
                    <span className="text-chart-4">{village.schemeEnrollment}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pending Claims:</span>
                    <span className="text-destructive">{village.pendingClaims}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
