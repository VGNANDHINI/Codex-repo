import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Search } from "lucide-react";
import FileUpload from "@/components/upload/file-upload";
import type { Village } from "@shared/schema";
import type { DashboardStats, StateFilter, MapLayerConfig } from "@/lib/types";

interface FraSidebarProps {
  selectedVillageId: string | null;
  onVillageSelect: (villageId: string | null) => void;
}

const stateFilters: StateFilter[] = [
  { state: "Madhya Pradesh", enabled: true, villageCount: 892 },
  { state: "Tripura", enabled: true, villageCount: 543 },
  { state: "Odisha", enabled: true, villageCount: 721 },
  { state: "Telangana", enabled: true, villageCount: 691 },
];

const mapLayers: MapLayerConfig[] = [
  { id: "village-boundaries", name: "Village Boundaries", enabled: true },
  { id: "forest-cover", name: "Forest Cover", enabled: true },
  { id: "water-bodies", name: "Water Bodies", enabled: false },
  { id: "agricultural-land", name: "Agricultural Land", enabled: false },
  { id: "infrastructure", name: "Infrastructure", enabled: false },
];

export default function FraSidebar({ selectedVillageId, onVillageSelect }: FraSidebarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [enabledStates, setEnabledStates] = useState<Set<string>>(
    new Set(stateFilters.filter(s => s.enabled).map(s => s.state))
  );
  const [enabledLayers, setEnabledLayers] = useState<Set<string>>(
    new Set(mapLayers.filter(l => l.enabled).map(l => l.id))
  );

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: selectedVillage } = useQuery<Village>({
    queryKey: ["/api/villages", selectedVillageId],
    enabled: !!selectedVillageId,
  });

  const handleStateToggle = (state: string, enabled: boolean) => {
    const newStates = new Set(enabledStates);
    if (enabled) {
      newStates.add(state);
    } else {
      newStates.delete(state);
    }
    setEnabledStates(newStates);
  };

  const handleLayerToggle = (layerId: string, enabled: boolean) => {
    const newLayers = new Set(enabledLayers);
    if (enabled) {
      newLayers.add(layerId);
    } else {
      newLayers.delete(layerId);
    }
    setEnabledLayers(newLayers);
  };

  return (
    <aside className="w-80 bg-card border-r border-border shadow-sm sidebar-scrollbar overflow-y-auto">
      <div className="p-6">
        {/* Quick Stats */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4 text-card-foreground">Quick Overview</h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-muted p-3 rounded-lg">
              <div className="text-2xl font-bold text-chart-1" data-testid="stat-total-villages">
                {stats?.totalVillages || 0}
              </div>
              <div className="text-xs text-muted-foreground">Total Villages</div>
            </div>
            <div className="bg-muted p-3 rounded-lg">
              <div className="text-2xl font-bold text-chart-2" data-testid="stat-active-claims">
                {stats?.activeClaims || 0}
              </div>
              <div className="text-xs text-muted-foreground">Active Claims</div>
            </div>
            <div className="bg-muted p-3 rounded-lg">
              <div className="text-2xl font-bold text-chart-3" data-testid="stat-pattas-granted">
                {stats?.pattasGranted || 0}
              </div>
              <div className="text-xs text-muted-foreground">Pattas Granted</div>
            </div>
            <div className="bg-muted p-3 rounded-lg">
              <div className="text-2xl font-bold text-chart-4" data-testid="stat-area-mapping">
                {stats?.areaMapping || 0}%
              </div>
              <div className="text-xs text-muted-foreground">Area Mapped</div>
            </div>
          </div>
        </div>

        {/* State Filter */}
        <div className="mb-6">
          <h3 className="text-md font-medium mb-3 text-card-foreground">Filter by State</h3>
          <div className="space-y-2">
            {stateFilters.map((filter) => (
              <label 
                key={filter.state}
                className="flex items-center space-x-3 cursor-pointer p-2 rounded hover:bg-muted transition-colors"
              >
                <Checkbox
                  checked={enabledStates.has(filter.state)}
                  onCheckedChange={(checked) => handleStateToggle(filter.state, !!checked)}
                  data-testid={`checkbox-state-${filter.state.toLowerCase().replace(/\s+/g, '-')}`}
                />
                <div className="flex-1">
                  <span className="text-sm font-medium">{filter.state}</span>
                  <div className="text-xs text-muted-foreground">{filter.villageCount} villages</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="mb-6">
          <h3 className="text-md font-medium mb-3 text-card-foreground">Search</h3>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search villages, patta holders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          </div>
        </div>

        {/* Map Layers */}
        <div className="mb-6">
          <h3 className="text-md font-medium mb-3 text-card-foreground">Map Layers</h3>
          <div className="space-y-2">
            {mapLayers.map((layer) => (
              <label key={layer.id} className="flex items-center space-x-3 cursor-pointer">
                <Checkbox
                  checked={enabledLayers.has(layer.id)}
                  onCheckedChange={(checked) => handleLayerToggle(layer.id, !!checked)}
                  data-testid={`checkbox-layer-${layer.id}`}
                />
                <span className="text-sm">{layer.name}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Data Upload */}
        <div className="mb-6">
          <h3 className="text-md font-medium mb-3 text-card-foreground">Upload FRA Data</h3>
          <div className="space-y-3">
            <FileUpload
              accept={[".pdf", ".doc", ".docx"]}
              category="application"
              placeholder="Drop FRA documents here"
              description="PDF, DOC, DOCX up to 50MB"
              data-testid="upload-fra-documents"
            />
            <FileUpload
              accept={[".shp", ".kml", ".geojson"]}
              category="spatial"
              placeholder="Drop shapefiles here"
              description="SHP, KML, GeoJSON"
              data-testid="upload-shapefiles"
            />
          </div>
        </div>

        {/* Selected Village Info */}
        {selectedVillage && (
          <div className="mb-6 bg-accent/20 rounded-lg border border-accent p-4">
            <h3 className="text-lg font-semibold mb-4 text-card-foreground">Village Details</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Village Name</label>
                <p className="text-sm" data-testid="text-village-name">{selectedVillage.name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">District</label>
                <p className="text-sm" data-testid="text-village-district">
                  {selectedVillage.district}, {selectedVillage.state}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Total Claims</label>
                <p className="text-sm" data-testid="text-village-claims">{selectedVillage.totalClaims}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Pattas Granted</label>
                <p className="text-sm" data-testid="text-village-pattas">{selectedVillage.pattasGranted}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Forest Area</label>
                <p className="text-sm" data-testid="text-village-forest-area">
                  {selectedVillage.forestArea} hectares
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
