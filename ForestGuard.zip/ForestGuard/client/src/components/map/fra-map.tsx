import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Village } from "@shared/schema";

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

interface FraMapProps {
  selectedVillageId: string | null;
  onVillageSelect: (villageId: string | null) => void;
}

export default function FraMap({ selectedVillageId, onVillageSelect }: FraMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  const mapContainerRef = useRef<HTMLDivElement>(null);

  const { data: villages = [] } = useQuery<Village[]>({
    queryKey: ["/api/villages"],
  });

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize map
    mapRef.current = L.map(mapContainerRef.current).setView([22.9734, 78.6569], 6);
    
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '© OpenStreetMap contributors',
    }).addTo(mapRef.current);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current || !villages.length) return;

    // Clear existing markers
    markersRef.current.forEach(marker => {
      mapRef.current!.removeLayer(marker);
    });
    markersRef.current.clear();

    // Add markers for villages
    villages.forEach(village => {
      const marker = L.marker([village.latitude, village.longitude]);
      
      // Create popup content
      const popupContent = `
        <div class="p-2">
          <h4 class="font-semibold text-base mb-1">${village.name}</h4>
          <p class="text-sm text-gray-600 mb-1">${village.state}</p>
          <p class="text-sm mb-1">Claims: ${village.totalClaims}</p>
          <p class="text-sm">Pattas: ${village.pattasGranted}</p>
        </div>
      `;
      
      marker.bindPopup(popupContent);
      
      // Handle marker click
      marker.on('click', () => {
        onVillageSelect(village.id);
      });

      marker.addTo(mapRef.current!);
      markersRef.current.set(village.id, marker);
    });
  }, [villages, onVillageSelect]);

  // Highlight selected village
  useEffect(() => {
    if (!selectedVillageId || !markersRef.current.has(selectedVillageId)) return;

    const selectedMarker = markersRef.current.get(selectedVillageId);
    if (selectedMarker) {
      selectedMarker.openPopup();
      mapRef.current?.setView(selectedMarker.getLatLng(), 10);
    }
  }, [selectedVillageId]);

  return (
    <div 
      ref={mapContainerRef} 
      className="h-full w-full rounded-lg"
      data-testid="map-container"
    />
  );
}
