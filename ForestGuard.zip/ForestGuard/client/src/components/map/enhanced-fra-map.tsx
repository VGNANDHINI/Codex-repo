import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Village } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Satellite, 
  Brain, 
  Activity, 
  TreePine, 
  Droplets, 
  Zap,
  Eye,
  RefreshCw,
  Layers,
  AlertTriangle
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

interface EnhancedFraMapProps {
  selectedVillageId: string | null;
  onVillageSelect: (villageId: string | null) => void;
}

// Custom marker icons for different statuses
const createCustomIcon = (color: string, icon: string) => {
  return L.divIcon({
    html: `
      <div style="
        background-color: ${color};
        width: 24px;
        height: 24px;
        border-radius: 50%;
        border: 2px solid white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 12px;
      ">
        ${icon}
      </div>
    `,
    className: 'custom-marker',
    iconSize: [24, 24],
    iconAnchor: [12, 12]
  });
};

export default function EnhancedFraMap({ selectedVillageId, onVillageSelect }: EnhancedFraMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const layerControlRef = useRef<L.Control.Layers | null>(null);
  
  const [activeLayer, setActiveLayer] = useState<'standard' | 'satellite' | 'forest' | 'water'>('standard');
  const [showSensorData, setShowSensorData] = useState(false);
  const [showAIInsights, setShowAIInsights] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const { data: villages = [] } = useQuery<Village[]>({
    queryKey: ["/api/villages"],
  });

  const { data: sensorData = [] } = useQuery({
    queryKey: ["/api/sensors"],
    enabled: showSensorData,
  });

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize map
    mapRef.current = L.map(mapContainerRef.current).setView([22.9734, 78.6569], 6);
    
    // Define different tile layers
    const standardLayer = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '© OpenStreetMap contributors',
    });

    const satelliteLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
      attribution: '© Esri, DigitalGlobe, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community',
    });

    const topoLayer = L.tileLayer("https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", {
      attribution: '© OpenTopoMap (CC-BY-SA)',
    });

    // Add default layer
    standardLayer.addTo(mapRef.current);

    // Create layer control
    const baseMaps = {
      "Standard": standardLayer,
      "Satellite": satelliteLayer,
      "Topographic": topoLayer
    };

    layerControlRef.current = L.control.layers(baseMaps).addTo(mapRef.current);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  const getMarkerIcon = (village: Village) => {
    if (!showAIInsights) {
      return createCustomIcon('#3b82f6', '📍');
    }

    // Color code based on AI insights
    if (village.forestHealthIndex !== null && village.forestHealthIndex < 40) {
      return createCustomIcon('#ef4444', '🌲'); // Red for poor forest health
    } else if (village.waterIndex !== null && village.waterIndex < 30) {
      return createCustomIcon('#f59e0b', '💧'); // Orange for water issues
    } else if (village.pattasGranted > village.totalClaims * 0.8) {
      return createCustomIcon('#10b981', '✅'); // Green for good FRA implementation
    } else {
      return createCustomIcon('#6366f1', '📍'); // Default blue
    }
  };

  const getHealthColor = (value: number | null) => {
    if (value === null) return 'text-gray-400';
    if (value >= 70) return 'text-green-600';
    if (value >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const analyzeVillageSatellite = async (villageId: string) => {
    setIsAnalyzing(true);
    try {
      await apiRequest(`/api/ai/analyze-satellite/${villageId}`, {
        method: 'POST'
      });
      // Refresh villages data to get updated satellite analysis
      window.location.reload();
    } catch (error) {
      console.error('Satellite analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateAIRecommendations = async (villageId: string) => {
    try {
      await apiRequest(`/api/dss/generate-recommendations/${villageId}`, {
        method: 'POST'
      });
      // Refresh to show new recommendations
      window.location.reload();
    } catch (error) {
      console.error('AI recommendation generation failed:', error);
    }
  };

  useEffect(() => {
    if (!mapRef.current || !villages.length) return;

    // Clear existing markers
    markersRef.current.forEach(marker => {
      mapRef.current!.removeLayer(marker);
    });
    markersRef.current.clear();

    // Add markers for villages
    villages.forEach(village => {
      const marker = L.marker([village.latitude, village.longitude], {
        icon: getMarkerIcon(village)
      });
      
      // Enhanced popup content with AI insights
      const popupContent = `
        <div class="w-80 p-3">
          <div class="flex items-center justify-between mb-2">
            <h4 class="font-semibold text-lg">${village.name}</h4>
            <span class="text-sm text-gray-500">${village.state}</span>
          </div>
          
          <div class="grid grid-cols-2 gap-2 mb-3">
            <div class="text-sm">
              <span class="text-gray-600">Claims:</span> ${village.totalClaims}
            </div>
            <div class="text-sm">
              <span class="text-gray-600">Pattas:</span> ${village.pattasGranted}
            </div>
            <div class="text-sm">
              <span class="text-gray-600">Population:</span> ${village.population}
            </div>
            <div class="text-sm">
              <span class="text-gray-600">Forest Area:</span> ${village.forestArea} ha
            </div>
          </div>

          ${showAIInsights ? `
            <div class="border-t pt-2 mb-3">
              <div class="text-sm font-medium mb-2 flex items-center">
                <span class="mr-1">🧠</span> AI Insights
              </div>
              <div class="space-y-1">
                <div class="flex justify-between text-xs">
                  <span>Forest Health:</span>
                  <span class="${getHealthColor(village.forestHealthIndex)}">
                    ${village.forestHealthIndex !== null ? village.forestHealthIndex + '%' : 'N/A'}
                  </span>
                </div>
                <div class="flex justify-between text-xs">
                  <span>Water Index:</span>
                  <span class="${getHealthColor(village.waterIndex)}">
                    ${village.waterIndex !== null ? village.waterIndex + '%' : 'N/A'}
                  </span>
                </div>
                <div class="flex justify-between text-xs">
                  <span>Soil Quality:</span>
                  <span class="${getHealthColor(village.soilQualityIndex)}">
                    ${village.soilQualityIndex !== null ? village.soilQualityIndex + '%' : 'N/A'}
                  </span>
                </div>
              </div>
            </div>
          ` : ''}

          <div class="flex gap-2">
            <button 
              onclick="window.selectVillage('${village.id}')"
              class="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
            >
              View Details
            </button>
            <button 
              onclick="window.analyzeSatellite('${village.id}')"
              class="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
              ${isAnalyzing ? 'disabled' : ''}
            >
              🛰️ Analyze
            </button>
          </div>
        </div>
      `;
      
      marker.bindPopup(popupContent, { 
        maxWidth: 320,
        className: 'custom-popup'
      });

      marker.addTo(mapRef.current!);
      markersRef.current.set(village.id, marker);
    });

    // Add global functions for popup buttons
    (window as any).selectVillage = (villageId: string) => {
      onVillageSelect(villageId);
    };

    (window as any).analyzeSatellite = (villageId: string) => {
      analyzeVillageSatellite(villageId);
    };

  }, [villages, onVillageSelect, showAIInsights, isAnalyzing]);

  // Highlight selected village
  useEffect(() => {
    if (!selectedVillageId || !markersRef.current.has(selectedVillageId)) return;

    const selectedMarker = markersRef.current.get(selectedVillageId);
    if (selectedMarker) {
      selectedMarker.openPopup();
      mapRef.current?.setView(selectedMarker.getLatLng(), 10);
    }
  }, [selectedVillageId]);

  return (
    <div className="relative h-full w-full">
      {/* Layer Controls */}
      <Card className="absolute top-4 right-4 z-[1000] w-72">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center">
            <Layers className="h-4 w-4 mr-2" />
            Map Controls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Button 
              variant={activeLayer === 'standard' ? 'default' : 'outline'} 
              size="sm" 
              onClick={() => setActiveLayer('standard')}
              className="text-xs"
            >
              Standard
            </Button>
            <Button 
              variant={activeLayer === 'satellite' ? 'default' : 'outline'} 
              size="sm" 
              onClick={() => setActiveLayer('satellite')}
              className="text-xs"
            >
              Satellite
            </Button>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm flex items-center">
                <Brain className="h-3 w-3 mr-1" />
                AI Insights
              </span>
              <Switch 
                checked={showAIInsights} 
                onCheckedChange={setShowAIInsights}
                data-testid="toggle-ai-insights"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm flex items-center">
                <Activity className="h-3 w-3 mr-1" />
                IoT Sensors
              </span>
              <Switch 
                checked={showSensorData} 
                onCheckedChange={setShowSensorData}
                data-testid="toggle-iot-sensors"
              />
            </div>
          </div>

          {showAIInsights && (
            <div className="pt-2 border-t">
              <div className="text-xs text-gray-600 mb-2">Legend:</div>
              <div className="space-y-1 text-xs">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                  Poor Forest Health
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                  Water Issues
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                  Good Implementation
                </div>
              </div>
            </div>
          )}

          {isAnalyzing && (
            <div className="pt-2 border-t">
              <div className="flex items-center text-sm text-blue-600">
                <RefreshCw className="h-3 w-3 mr-2 animate-spin" />
                Analyzing satellite data...
              </div>
              <Progress value={33} className="mt-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Map Container */}
      <div 
        ref={mapContainerRef} 
        className="h-full w-full rounded-lg"
        data-testid="enhanced-map-container"
      />

      {/* AI Analysis Status */}
      {showAIInsights && (
        <Card className="absolute bottom-4 left-4 z-[1000] w-64">
          <CardContent className="p-3">
            <div className="text-sm font-medium mb-2 flex items-center">
              <Satellite className="h-4 w-4 mr-2" />
              AI Analysis Status
            </div>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span>Villages Analyzed:</span>
                <span className="font-medium">
                  {villages.filter(v => v.lastAiAnalysis).length}/{villages.length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Forest Health Data:</span>
                <span className="font-medium">
                  {villages.filter(v => v.forestHealthIndex !== null).length}/{villages.length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Water Quality Data:</span>
                <span className="font-medium">
                  {villages.filter(v => v.waterIndex !== null).length}/{villages.length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}