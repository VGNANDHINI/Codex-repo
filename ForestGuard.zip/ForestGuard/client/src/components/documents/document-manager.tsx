import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, Filter, Download, FileText, Image } from "lucide-react";
import type { Document } from "@shared/schema";

const documentCategories = [
  { id: "application", name: "FRA Applications", icon: FileText, count: 2847 },
  { id: "patta", name: "Granted Pattas", icon: FileText, count: 856 },
  { id: "survey", name: "Survey Reports", icon: FileText, count: 1293 },
  { id: "satellite", name: "Satellite Data", icon: Image, count: 4156 },
];

export default function DocumentManager() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: documents = [] } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });

  // Mock recent documents for demonstration
  const mockDocuments = [
    {
      id: "1",
      fileName: "FRA-MP-2024-001_Application.pdf",
      category: "application",
      village: "Chiraidongri Village",
      uploadedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      processed: true
    },
    {
      id: "2", 
      fileName: "Satellite_Imagery_Kanchanpur_2024.tif",
      category: "satellite",
      village: "Kanchanpur Village",
      uploadedAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      processed: false
    }
  ];

  const getFileIcon = (fileName: string) => {
    if (fileName.toLowerCase().includes('.pdf')) {
      return <FileText className="text-chart-1 text-lg" />;
    }
    return <Image className="text-chart-2 text-lg" />;
  };

  const getProcessedBadge = (processed: boolean) => {
    return processed 
      ? <Badge className="bg-secondary/20 text-secondary">Processed</Badge>
      : <Badge className="bg-chart-4/20 text-chart-4">Processing</Badge>;
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else {
      return 'Just now';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Document Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Document Categories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {documentCategories.map((category) => {
            const IconComponent = category.icon;
            return (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`w-full text-left p-3 rounded hover:bg-muted transition-colors border border-transparent hover:border-border ${
                  selectedCategory === category.id ? 'bg-muted border-border' : ''
                }`}
                data-testid={`button-category-${category.id}`}
              >
                <div className="flex items-center space-x-3">
                  <IconComponent className="h-5 w-5 text-chart-1" />
                  <div>
                    <div className="text-sm font-medium">{category.name}</div>
                    <div className="text-xs text-muted-foreground">{category.count} documents</div>
                  </div>
                </div>
              </button>
            );
          })}
        </CardContent>
      </Card>

      {/* Document List */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Documents</CardTitle>
              <div className="flex space-x-2">
                <Button size="sm" data-testid="button-upload-documents">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload
                </Button>
                <Button variant="outline" size="sm" data-testid="button-filter-documents">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="divide-y divide-border">
              {mockDocuments.map((doc) => (
                <div 
                  key={doc.id} 
                  className="p-4 hover:bg-muted/50 transition-colors"
                  data-testid={`row-document-${doc.id}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getFileIcon(doc.fileName)}
                      <div>
                        <div className="text-sm font-medium" data-testid={`text-filename-${doc.id}`}>
                          {doc.fileName}
                        </div>
                        <div className="text-xs text-muted-foreground" data-testid={`text-details-${doc.id}`}>
                          {doc.village} • Uploaded {formatTimeAgo(doc.uploadedAt)}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getProcessedBadge(doc.processed)}
                      <Button variant="ghost" size="sm" data-testid={`button-download-${doc.id}`}>
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
