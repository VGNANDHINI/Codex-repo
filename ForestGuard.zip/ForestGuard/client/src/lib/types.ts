export interface MapLayerConfig {
  id: string;
  name: string;
  enabled: boolean;
  color?: string;
}

export interface StateFilter {
  state: string;
  enabled: boolean;
  villageCount: number;
}

export interface TabConfig {
  id: string;
  name: string;
  icon: string;
  active: boolean;
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
}

export interface FileUploadConfig {
  accept: string[];
  maxSize: number;
  category: string;
}

export interface VillageAssets {
  agriculturalLand?: number;
  waterBodies?: number;
  forestCover?: number;
  homesteads?: number;
}

export interface DashboardStats {
  totalVillages: number;
  activeClaims: number;
  pattasGranted: number;
  areaMapping: number;
}
