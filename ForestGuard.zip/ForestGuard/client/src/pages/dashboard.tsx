import { useState } from "react";
import FraSidebar from "@/components/sidebar/fra-sidebar";
import EnhancedFraMap from "@/components/map/enhanced-fra-map";
import StatsOverview from "@/components/dashboard/stats-overview";
import ChartsSection from "@/components/dashboard/charts-section";
import ApplicationsTable from "@/components/dashboard/applications-table";
import RecommendationsPanel from "@/components/dss/recommendations-panel";
import DocumentManager from "@/components/documents/document-manager";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Upload, 
  Network, 
  UserCircle, 
  Brain, 
  Satellite, 
  Activity, 
  Zap, 
  FileText, 
  TreePine, 
  Droplets, 
  AlertTriangle 
} from "lucide-react";
import type { TabConfig } from "@/lib/types";

const tabs: TabConfig[] = [
  { id: "atlas", name: "AI-Powered Atlas", icon: "map", active: true },
  { id: "dashboard", name: "Analytics", icon: "chart-bar", active: false },
  { id: "ai-insights", name: "AI Insights", icon: "brain", active: false },
  { id: "dss", name: "Decision Support", icon: "lightbulb", active: false },
  { id: "documents", name: "Documents", icon: "folder", active: false },
  { id: "iot-sensors", name: "IoT Monitoring", icon: "activity", active: false },
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("atlas");
  const [selectedVillageId, setSelectedVillageId] = useState<string | null>(null);

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "atlas":
        return (
          <div className="h-full grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3 bg-card rounded-lg shadow-sm border border-border overflow-hidden">
              <EnhancedFraMap 
                selectedVillageId={selectedVillageId}
                onVillageSelect={setSelectedVillageId}
              />
            </div>
            <div className="space-y-6">
              <StatsOverview villageId={selectedVillageId} />
            </div>
          </div>
        );
      case "dashboard":
        return (
          <div className="space-y-6">
            <ChartsSection />
            <ApplicationsTable />
          </div>
        );
      case "ai-insights":
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="bg-card rounded-lg p-6 border border-border">
                  <h2 className="text-lg font-semibold mb-4 flex items-center">
                    <Brain className="h-5 w-5 mr-2 text-blue-600" />
                    AI Processing Status
                  </h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-950/20 rounded">
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-2 text-blue-600" />
                        <span className="text-sm">Document Processing</span>
                      </div>
                      <Badge variant="secondary">OCR + NER Ready</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950/20 rounded">
                      <div className="flex items-center">
                        <Satellite className="h-4 w-4 mr-2 text-green-600" />
                        <span className="text-sm">Satellite Analysis</span>
                      </div>
                      <Badge variant="secondary">Land-Use Classification</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-950/20 rounded">
                      <div className="flex items-center">
                        <Zap className="h-4 w-4 mr-2 text-purple-600" />
                        <span className="text-sm">Predictive Analytics</span>
                      </div>
                      <Badge variant="secondary">DSS Recommendations</Badge>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div className="bg-card rounded-lg p-6 border border-border">
                  <h3 className="text-sm font-medium mb-3">AI Model Performance</h3>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>OCR Accuracy</span>
                        <span>94.2%</span>
                      </div>
                      <Progress value={94.2} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>NER Precision</span>
                        <span>87.8%</span>
                      </div>
                      <Progress value={87.8} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Satellite Classification</span>
                        <span>91.5%</span>
                      </div>
                      <Progress value={91.5} className="h-2" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case "dss":
        return <RecommendationsPanel />;
      case "documents":
        return <DocumentManager />;
      case "iot-sensors":
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <Activity className="h-8 w-8 text-blue-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Active Sensors</p>
                      <p className="text-2xl font-bold">127</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <Droplets className="h-8 w-8 text-blue-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Water Quality</p>
                      <p className="text-2xl font-bold">Good</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <TreePine className="h-8 w-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Forest Health</p>
                      <p className="text-2xl font-bold">78%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <AlertTriangle className="h-8 w-8 text-orange-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Alerts</p>
                      <p className="text-2xl font-bold">3</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="bg-card rounded-lg p-6 border border-border">
              <h2 className="text-lg font-semibold mb-4">Real-time Monitoring Dashboard</h2>
              <p className="text-muted-foreground">IoT sensor data visualization and monitoring interface will be displayed here.</p>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary shadow-sm border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Network className="text-primary-foreground text-2xl" />
              <div>
                <h1 className="text-xl font-bold text-primary-foreground">AI-Powered FRA Atlas & WebGIS DSS</h1>
                <p className="text-sm text-primary-foreground/80">Intelligent Forest Rights Act Monitoring with ML & IoT</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="secondary"
              size="sm"
              className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
              data-testid="button-upload-data"
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Data
            </Button>
            <div className="flex items-center space-x-2 text-primary-foreground/80">
              <UserCircle className="h-5 w-5" />
              <span className="text-sm">Admin Portal</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Sidebar */}
        <FraSidebar 
          selectedVillageId={selectedVillageId}
          onVillageSelect={setSelectedVillageId}
        />

        {/* Main Content */}
        <main className="flex-1 flex flex-col">
          {/* Navigation Tabs */}
          <div className="bg-card border-b border-border px-6 py-3">
            <nav className="flex space-x-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    activeTab === tab.id
                      ? "text-primary border-b-2 border-primary bg-primary/5 rounded-t"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  data-testid={`tab-${tab.id}`}
                >
                  <i className={`fas fa-${tab.icon} mr-2`}></i>
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="flex-1 p-6">
            {renderTabContent()}
          </div>
        </main>
      </div>
    </div>
  );
}
